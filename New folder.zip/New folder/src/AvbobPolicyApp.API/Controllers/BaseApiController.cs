using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace AvbobPolicyApp.API.Controllers
{
    /// <summary>
    /// Base API controller that provides common functionality for all API controllers
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public abstract class BaseApiController : ControllerBase
    {
        private readonly ILogger _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseApiController"/> class.
        /// </summary>
        /// <param name="logger">The logger instance for this controller.</param>
        protected BaseApiController(ILogger logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Handles the result of an operation and returns an appropriate IActionResult
        /// </summary>
        /// <typeparam name="T">Type of the result</typeparam>
        /// <param name="result">The result to return</param>
        /// <param name="notFoundMessage">Optional message to return if the result is null</param>
        /// <returns>OkObjectResult with the result, or NotFoundObjectResult if the result is null</returns>
        protected IActionResult HandleResult<T>(T result, string notFoundMessage = null) where T : class
        {
            if (result == null)
            {
                _logger.LogWarning($"Resource not found: {notFoundMessage}");
                return NotFound(new { message = notFoundMessage ?? "The requested resource was not found" });
            }

            return Ok(result);
        }

        /// <summary>
        /// Handles the result of a create operation and returns a CreatedAtActionResult
        /// </summary>
        /// <typeparam name="T">Type of the created resource</typeparam>
        /// <param name="result">The created resource</param>
        /// <param name="actionName">The name of the action to use for generating the URL</param>
        /// <param name="routeValues">The route values to use for generating the URL</param>
        /// <param name="errorMessage">Optional error message if the operation fails</param>
        /// <returns>CreatedAtActionResult if successful, BadRequestObjectResult if not</returns>
        protected IActionResult HandleCreatedResult<T>(T result, string actionName, object routeValues, string errorMessage = null) where T : class
        {
            if (result == null)
            {
                _logger.LogWarning($"Failed to create resource: {errorMessage}");
                return BadRequest(new { message = errorMessage ?? "Failed to create the resource" });
            }

            return CreatedAtAction(actionName, routeValues, result);
        }

        /// <summary>
        /// Handles an exception and returns an appropriate error response
        /// </summary>
        /// <param name="ex">The exception that occurred</param>
        /// <param name="customMessage">Optional custom error message</param>
        /// <returns>ObjectResult with error details</returns>
        protected IActionResult HandleException(Exception ex, string customMessage = null)
        {
            _logger.LogError(ex, customMessage ?? "An error occurred while processing the request");
            
            return StatusCode(StatusCodes.Status500InternalServerError, new 
            { 
                message = customMessage ?? "An error occurred while processing your request",
                details = ex.Message,
                stackTrace = HttpContext.RequestServices.GetService(typeof(IHostEnvironment)) is IWebHostEnvironment env && 
                            env.IsDevelopment() ? ex.StackTrace : null
            });
        }

        /// <summary>
        /// Executes an async operation and handles any exceptions that occur
        /// </summary>
        /// <typeparam name="T">The type of the result</typeparam>
        /// <param name="action">The async operation to execute</param>
        /// <param name="customErrorMessage">Optional custom error message</param>
        /// <returns>IActionResult with the result of the operation or an error response</returns>
        protected async Task<IActionResult> ExecuteAndHandleErrorsAsync<T>(Func<Task<T>> action, string customErrorMessage = null)
        {
            try
            {
                var result = await action();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return HandleException(ex, customErrorMessage);
            }
        }

        /// <summary>
        /// Validates the model state and returns a BadRequestObjectResult if it's invalid
        /// </summary>
        /// <returns>BadRequestObjectResult if the model state is invalid, null otherwise</returns>
        protected IActionResult ValidateModelState()
        {
            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Model validation failed: {Errors}", ModelState);
                return BadRequest(new 
                { 
                    message = "Invalid request data", 
                    errors = ModelState.Values
                        .SelectMany(v => v.Errors)
                        .Select(e => e.ErrorMessage)
                });
            }
            return null;
        }
    }
}
