using AvbobPolicyApp.Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace AvbobPolicyApp.Infrastructure.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) 
            : base(options)
        {
        }

        public DbSet<PolicyHolder> PolicyHolders { get; set; } = null!;
        public DbSet<Policy> Policies { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure PolicyHolder entity
            modelBuilder.Entity<PolicyHolder>()
                .HasMany(ph => ph.Policies)
                .WithOne(p => p.PolicyHolder)
                .HasForeignKey(p => p.PolicyHolderId)
                .OnDelete(DeleteBehavior.Cascade);

            // Configure Policy entity
            modelBuilder.Entity<Policy>()
                .Property(p => p.Installment)
                .HasColumnType("decimal(18,2)");
        }
    }
}
