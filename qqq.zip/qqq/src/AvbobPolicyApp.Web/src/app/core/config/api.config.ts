/**
 * API Configuration
 * Contains all API endpoints and related settings
 */
export const API_CONFIG = {
  // Base API URL - should be set from environment in production
  baseUrl: 'http://localhost:5000/api',
  
  // API endpoints
  endpoints: {
    policyHolders: {
      base: '/policyholders',
      search: '/policyholders', // Using query params for search
      byIdNumber: '/policyholders/search/id-number',
      policies: (id: number) => `/policyholders/${id}/policies`
    },
    policies: {
      base: '/policies',
      upload: (id: number) => `/policies/${id}/documents`
    }
  },
  
  // Pagination settings
  pagination: {
    defaultPageSize: 20,
    maxPageSize: 100,
    pageSizeOptions: [10, 20, 50, 100]
  },
  
  // File upload settings
  fileUpload: {
    maxSize: 10 * 1024 * 1024, // 10MB
    allowedTypes: [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'image/jpeg',
      'image/png'
    ],
    allowedExtensions: ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.jpg', '.jpeg', '.png']
  },
  
  // API request settings
  request: {
    timeout: 30000, // 30 seconds
    retryAttempts: 3,
    retryDelay: 1000 // 1 second
  },
  
  // CORS settings
  cors: {
    withCredentials: true,
    allowedOrigins: ['http://localhost:4200', 'https://localhost:4200']
  }
};

/**
 * Helper function to build query parameters
 */
export function buildQueryParams(params: { [key: string]: any }): string {
  const queryParams = new URLSearchParams();
  
  Object.entries(params).forEach(([key, value]) => {
    if (value !== null && value !== undefined) {
      if (Array.isArray(value)) {
        value.forEach(item => queryParams.append(key, item));
      } else {
        queryParams.append(key, value);
      }
    }
  });
  
  const queryString = queryParams.toString();
  return queryString ? `?${queryString}` : '';
}

/**
 * Helper function to build pagination headers
 */
export interface PaginationInfo {
  totalCount: number;
  pageSize: number;
  currentPage: number;
  totalPages: number;
  [key: string]: any;
}

export function getPaginationInfo(headers: any): PaginationInfo | null {
  const paginationHeader = headers.get('X-Pagination');
  if (!paginationHeader) return null;
  
  try {
    return JSON.parse(paginationHeader);
  } catch (error) {
    console.error('Error parsing pagination header:', error);
    return null;
  }
}
