import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { API_CONFIG } from '../config/api.config';
import { Policy, ApiResponse } from '../../models/policy.model';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  private readonly baseUrl = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.policies}`;

  constructor(private http: HttpClient) {}

  // Get all policies
  getPolicies(): Observable<Policy[]> {
    return this.http.get<ApiResponse<Policy[]>>(this.baseUrl).pipe(
      map(response => response.data || [])
    );
  }

  // Get policy by ID
  getPolicy(id: number): Observable<Policy> {
    return this.http.get<ApiResponse<Policy>>(`${this.baseUrl}/${id}`).pipe(
      map(response => response.data!)
    );
  }

  // Get policy by policy number
  getPolicyByNumber(policyNumber: string): Observable<Policy> {
    return this.http.get<ApiResponse<Policy>>(`${this.baseUrl}/number/${policyNumber}`).pipe(
      map(response => response.data!)
    );
  }

  // Get policies by policy holder ID
  getPoliciesByHolderId(holderId: number): Observable<Policy[]> {
    return this.http.get<ApiResponse<Policy[]>>(`${this.baseUrl}/holder/${holderId}`).pipe(
      map(response => response.data || [])
    );
  }

  // Create a new policy
  createPolicy(policy: Policy): Observable<Policy> {
    return this.http.post<ApiResponse<Policy>>(this.baseUrl, policy).pipe(
      map(response => response.data!)
    );
  }

  // Update an existing policy
  updatePolicy(id: number, policy: Policy): Observable<void> {
    return this.http.put<ApiResponse<void>>(`${this.baseUrl}/${id}`, policy).pipe(
      map(() => {})
    );
  }

  // Delete a policy
  deletePolicy(id: number): Observable<void> {
    return this.http.delete<ApiResponse<void>>(`${this.baseUrl}/${id}`).pipe(
      map(() => {})
    );
  }

  // Upload a document for a policy
  uploadPolicyDocument(policyId: number, file: File): Observable<{ filePath: string }> {
    const formData = new FormData();
    formData.append('file', file, file.name);

    return this.http.post<ApiResponse<{ filePath: string }>>(
      `${this.baseUrl}/${policyId}/documents`,
      formData
    ).pipe(
      map(response => response.data!)
    );
  }
}
