using System;
using System.IO;
using System.Threading.Tasks;
using AvbobPolicyApp.Core.Interfaces;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;

namespace AvbobPolicyApp.Infrastructure.Services
{
    public class LocalFileStorageService : IFileStorageService, IDisposable
    {
        private readonly string _basePath;
        private readonly ILogger<LocalFileStorageService> _logger;
        private bool _disposed = false;

        public LocalFileStorageService(string basePath, ILogger<LocalFileStorageService> logger = null)
        {
            if (string.IsNullOrEmpty(basePath))
                throw new ArgumentException("Base path cannot be null or empty", nameof(basePath));

            _basePath = Path.Combine(AppContext.BaseDirectory, basePath);
            _logger = logger;
            
            try
            {
                // Ensure the directory exists
                Directory.CreateDirectory(_basePath);
                _logger?.LogInformation($"File storage initialized at: {_basePath}");
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Failed to initialize file storage");
                throw new InvalidOperationException("Failed to initialize file storage", ex);
            }
        }

        public async Task<string> SaveFileAsync(string folderPath, string fileName, Stream fileStream)
        {
            if (string.IsNullOrEmpty(fileName))
                throw new ArgumentException("File name cannot be null or empty", nameof(fileName));
                
            if (fileStream == null)
                throw new ArgumentNullException(nameof(fileStream));
                
            if (_disposed)
                throw new ObjectDisposedException(nameof(LocalFileStorageService));

            string fullPath;
            try
            {
                // Combine the base path, folder path, and file name
                fullPath = Path.Combine(_basePath, folderPath ?? string.Empty, fileName);
                var directory = Path.GetDirectoryName(fullPath);
                
                // Ensure the directory exists
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                // Reset stream position if possible
                if (fileStream.CanSeek && fileStream.Position > 0)
                {
                    fileStream.Position = 0;
                }

                // Save the file
                using (var file = new FileStream(fullPath, FileMode.Create, FileAccess.Write, FileShare.None, 4096, true))
                {
                    await fileStream.CopyToAsync(file);
                }

                return fullPath;
            }
            catch (Exception ex) when (ex is not InvalidOperationException)
            {
                _logger?.LogError(ex, $"Error saving file {fileName}");
                throw new InvalidOperationException($"Failed to save file {fileName}", ex);
            }
        }

        public async Task<Stream> GetFileAsync(string filePath)
        {
            if (string.IsNullOrEmpty(filePath))
                return null;
                
            if (_disposed)
                throw new ObjectDisposedException(nameof(LocalFileStorageService));

            try
            {
                var fullPath = Path.Combine(_basePath, filePath.TrimStart(Path.DirectorySeparatorChar));
                
                if (!File.Exists(fullPath))
                {
                    _logger?.LogWarning($"File not found: {filePath}");
                    return null;
                }

                var memory = new MemoryStream();
                using (var stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.Read, 4096, true))
                {
                    await stream.CopyToAsync(memory);
                }
                memory.Position = 0;
                return memory;
            }
            catch (Exception ex) when (ex is not InvalidOperationException)
            {
                _logger?.LogError(ex, $"Error retrieving file {filePath}");
                throw new InvalidOperationException($"Failed to retrieve file {filePath}", ex);
            }
        }

        public Task<bool> DeleteFileAsync(string filePath)
        {
            if (string.IsNullOrEmpty(filePath))
                return Task.FromResult(false);
                
            if (_disposed)
                throw new ObjectDisposedException(nameof(LocalFileStorageService));

            try
            {
                var fullPath = Path.Combine(_basePath, filePath.TrimStart(Path.DirectorySeparatorChar));
                
                if (!File.Exists(fullPath))
                {
                    _logger?.LogWarning($"File not found for deletion: {filePath}");
                    return Task.FromResult(false);
                }

                File.Delete(fullPath);
                return Task.FromResult(true);
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, $"Error deleting file {filePath}");
                return Task.FromResult(false);
            }
        }
        
        public async Task<bool> FileExistsAsync(string filePath)
        {
            if (string.IsNullOrEmpty(filePath) || _disposed)
                return false;
                
            try
            {
                var fullPath = Path.Combine(_basePath, filePath.TrimStart(Path.DirectorySeparatorChar));
                return await Task.Run(() => File.Exists(fullPath));
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, $"Error checking if file exists: {filePath}");
                return false;
            }
        }
        
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                // No unmanaged resources to clean up
                _disposed = true;
            }
        }
        
        ~LocalFileStorageService()
        {
            Dispose(false);
        }
    }
}
