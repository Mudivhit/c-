# Avbob Policy Management System - Backend

## Overview
This is the backend service for the Avbob Policy Management System, built with .NET Core. It provides RESTful APIs for managing policy holders and their insurance policies.

## Prerequisites
- .NET 6.0 SDK or later
- SQL Server (LocalDB, Express, or full version)
- Visual Studio 2022 or VS Code with C# extension

## Getting Started

### 1. Clone the Repository
```bash
git clone [repository-url]
cd AvbobPolicyApp
```

### 2. Database Setup
1. Update the connection string in `appsettings.json`:
```json
"ConnectionStrings": {
  "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=AvbobPolicyApp;Trusted_Connection=True;MultipleActiveResultSets=true"
}
```

2. Apply database migrations:
```bash
cd src/AvbobPolicyApp.API
dotnet ef database update
```

### 3. Run the Application
```bash
dotnet run
```
The API will be available at:
- `https://localhost:5001` (HTTPS)
- `http://localhost:5000` (HTTP)

## API Documentation

### Policy Holders
- `GET /api/policyholders` - Get all policy holders
- `GET /api/policyholders/{id}` - Get policy holder by ID
- `GET /api/policyholders/idnumber/{idNumber}` - Get policy holder by ID number
- `GET /api/policyholders/search?term={searchTerm}` - Search policy holders
- `POST /api/policyholders` - Create a new policy holder
- `PUT /api/policyholders/{id}` - Update a policy holder
- `DELETE /api/policyholders/{id}` - Delete a policy holder

### Policies
- `GET /api/policies` - Get all policies
- `GET /api/policies/{id}` - Get policy by ID
- `GET /api/policies/number/{policyNumber}` - Get policy by policy number
- `GET /api/policies/holder/{holderId}` - Get policies by holder ID
- `POST /api/policies` - Create a new policy
- `PUT /api/policies/{id}` - Update a policy
- `DELETE /api/policies/{id}` - Delete a policy
- `POST /api/policies/{id}/documents` - Upload a document for a policy

## Project Structure
- `src/AvbobPolicyApp.API` - API Controllers and Startup configuration
- `src/AvbobPolicyApp.Core` - Domain models and business logic
- `src/AvbobPolicyApp.Infrastructure` - Data access and external services
- `src/AvbobPolicyApp.Shared` - Shared DTOs and utilities

## Configuration
Environment-specific settings can be configured in:
- `appsettings.json` - Default configuration
- `appsettings.Development.json` - Development environment overrides

## Deployment
### Publish the Application
```bash
dotnet publish -c Release -o ./publish
```

### Docker Support
Build the Docker image:
```bash
docker build -t avbob-policy-app .
```

Run the container:
```bash
docker run -p 5000:80 -e "ASPNETCORE_ENVIRONMENT=Production" avbob-policy-app
```
