import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { Subject, Observable, of } from 'rxjs';
import { PolicyHolder, PolicyHolderSearchResult } from '../../models/policy-holder.model';
import { PaginatedResponse } from '../../models/policy.model';
import { PolicyHolderService } from '../../core/services/policy-holder.service';

@Component({
  selector: 'app-policy-holder-details',
  templateUrl: './policy-holder-details.component.html',
  styleUrls: ['./policy-holder-details.component.scss']
})
export class PolicyHolderDetailsComponent implements OnChanges {
  @Input() policyHolder: PolicyHolder | null = null;
  @Output() save = new EventEmitter<Partial<PolicyHolder>>();
  @Output() policyHolderSelected = new EventEmitter<PolicyHolder>();
  
  form: FormGroup;
  searchResults: PolicyHolderSearchResult[] = [];
  private searchTerms = new Subject<string>();
  isSearching = false;
  
  genders = [
    { value: 'M', display: 'Male' },
    { value: 'F', display: 'Female' },
    { value: 'O', display: 'Other' }
  ];

  constructor(
    private fb: FormBuilder,
    private policyHolderService: PolicyHolderService
  ) {
    this.form = this.fb.group({
      idNumber: ['', [Validators.required, Validators.pattern('^[0-9]{13}$')]],
      initials: ['', Validators.required],
      surname: ['', Validators.required],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required]
    });

    // Setup search with debounce
    this.setupSearch();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['policyHolder'] && this.policyHolder) {
      this.form.patchValue({
        idNumber: this.policyHolder.idNumber,
        initials: this.policyHolder.initials,
        surname: this.policyHolder.surname,
        dateOfBirth: this.formatDate(this.policyHolder.dateOfBirth),
        gender: this.policyHolder.gender
      });
    }
  }

  private setupSearch() {
    this.searchTerms.pipe(
      // wait 300ms after each keystroke before considering the term
      debounceTime(300),
      // ignore new term if same as previous term
      distinctUntilChanged(),
      // switch to new search observable each time the term changes
      switchMap((term: string) => {
        if (term.length < 3) {
          this.searchResults = [];
          return of([]);
        }
        this.isSearching = true;
        return this.policyHolderService.searchPolicyHolders(term);
      })
    ).subscribe({
      next: (results: PolicyHolderSearchResult[]) => {
        this.searchResults = results;
        this.isSearching = false;
      },
      error: () => {
        this.searchResults = [];
        this.isSearching = false;
      }
    });
  }

  onIdNumberInput(event: Event) {
    const input = (event.target as HTMLInputElement).value;
    this.searchTerms.next(input);
  }

  selectSearchResult(result: PolicyHolderSearchResult) {
    this.policyHolderService.getPolicyHolderByIdNumber(result.idNumber).subscribe({
      next: (policyHolder: PolicyHolder) => {
        this.form.patchValue({
          idNumber: policyHolder.idNumber,
          initials: policyHolder.initials,
          surname: policyHolder.surname,
          dateOfBirth: this.formatDate(policyHolder.dateOfBirth),
          gender: policyHolder.gender
        });
        this.searchResults = [];
        this.policyHolderSelected.emit(policyHolder);
      },
      error: (error: any) => {
        console.error('Error loading policy holder:', error);
      }
    });
  }

  private formatDate(date: string | Date): string {
    if (!date) return '';
    const d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
  }

  onReset() {
    if (this.policyHolder) {
      this.form.patchValue({
        idNumber: this.policyHolder.idNumber,
        initials: this.policyHolder.initials,
        surname: this.policyHolder.surname,
        dateOfBirth: this.formatDate(this.policyHolder.dateOfBirth),
        gender: this.policyHolder.gender
      });
    } else {
      this.form.reset();
    }
  }

  onSubmit() {
    if (this.form.valid) {
      this.save.emit({
        ...this.form.value,
        id: this.policyHolder?.id
      });
    } else {
      // Mark all fields as touched to show validation messages
      Object.keys(this.form.controls).forEach(key => {
        this.form.get(key)?.markAsTouched();
      });
    }
  }
}
