using System.IO;
using System.Threading.Tasks;

namespace AvbobPolicyApp.Core.Interfaces
{
    public interface IFileStorageService
    {
        Task<string> SaveFileAsync(string folderPath, string fileName, Stream fileStream);
        Task<Stream> GetFileAsync(string filePath);
        Task<bool> DeleteFileAsync(string filePath);
        Task<bool> FileExistsAsync(string filePath);
    }
}
