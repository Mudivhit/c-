using AvbobPolicyApp.Core.Entities;
using AvbobPolicyApp.Core.Interfaces;
using AvbobPolicyApp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace AvbobPolicyApp.Infrastructure.Repositories
{
    public class PolicyRepository : Repository<Policy>, IPolicyRepository
    {
        private readonly AppDbContext _context;

        public PolicyRepository(AppDbContext context) : base(context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Policy>> GetPoliciesByHolderIdAsync(int holderId)
        {
            return await _context.Policies
                .Where(p => p.PolicyHolderId == holderId)
                .ToListAsync();
        }

        public async Task<Policy?> GetByPolicyNumberAsync(string policyNumber)
        {
            return await _context.Policies
                .FirstOrDefaultAsync(p => p.PolicyNumber == policyNumber);
        }
    }
}
