using System;
using System.IO;
using System.Threading.Tasks;
using AvbobPolicyApp.Core.Interfaces;
using Microsoft.Extensions.Configuration;

namespace AvbobPolicyApp.Infrastructure.Services
{
    public class FileStorageService : IFileStorageService, IDisposable
    {
        private readonly string _basePath;
        private readonly string _drBasePath; // Disaster Recovery path
        private readonly bool _enableDrReplication;
        private bool _disposed = false;

        public FileStorageService(IConfiguration configuration)
        {
            _basePath = configuration["FileStorage:BasePath"] ?? "wwwroot/uploads";
            _drBasePath = configuration["FileStorage:DisasterRecoveryPath"] ?? "D:\\BackupUploads";
            _enableDrReplication = bool.TryParse(configuration["FileStorage:EnableDisasterRecovery"], out var enableDr) ? enableDr : true;

            // Ensure base directories exist
            Directory.CreateDirectory(_basePath);
            
            if (_enableDrReplication)
            {
                Directory.CreateDirectory(_drBasePath);
            }
        }

        public async Task<string> SaveFileAsync(string folderPath, string fileName, Stream fileStream)
        {
            if (string.IsNullOrWhiteSpace(fileName))
                throw new ArgumentException("File name cannot be empty", nameof(fileName));

            if (fileStream == null || fileStream.Length == 0)
                throw new ArgumentException("File stream cannot be empty", nameof(fileStream));

            // Create the full path
            var relativePath = string.IsNullOrEmpty(folderPath) ? fileName : Path.Combine(folderPath, fileName);
            var fullPath = Path.Combine(_basePath, relativePath);
            var fullDrPath = _enableDrReplication ? Path.Combine(_drBasePath, relativePath) : null;

            // Ensure the directory exists
            var directory = Path.GetDirectoryName(fullPath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            // Save to primary location
            using (var fileStreamToWrite = new FileStream(fullPath, FileMode.Create))
            {
                await fileStream.CopyToAsync(fileStreamToWrite);
            }

            // If DR is enabled, save to DR location
            if (_enableDrReplication && !string.IsNullOrEmpty(fullDrPath))
            {
                try
                {
                    var drDirectory = Path.GetDirectoryName(fullDrPath);
                    if (!string.IsNullOrEmpty(drDirectory) && !Directory.Exists(drDirectory))
                    {
                        Directory.CreateDirectory(drDirectory);
                    }

                    fileStream.Position = 0; // Reset stream position
                    using (var drFileStream = new FileStream(fullDrPath, FileMode.Create))
                    {
                        await fileStream.CopyToAsync(drFileStream);
                    }
                }
                catch (Exception ex)
                {
                    // Log the error but don't fail the operation
                    // In a production environment, you'd want to log this to a monitoring system
                    Console.WriteLine($"Failed to save file to DR location: {ex.Message}");
                }
            }

            return relativePath.Replace('\\', '/'); // Return consistent path separators
        }

        public async Task<Stream> GetFileAsync(string filePath)
        {
            if (string.IsNullOrWhiteSpace(filePath))
                throw new ArgumentException("File path cannot be empty", nameof(filePath));

            // Try primary location first
            var fullPath = Path.Combine(_basePath, filePath);
            if (File.Exists(fullPath))
            {
                var memoryStream = new MemoryStream();
                using (var fileStream = new FileStream(fullPath, FileMode.Open, FileAccess.Read))
                {
                    await fileStream.CopyToAsync(memoryStream);
                }
                memoryStream.Position = 0;
                return memoryStream;
            }

            // If not found in primary and DR is enabled, try DR location
            if (_enableDrReplication)
            {
                var fullDrPath = Path.Combine(_drBasePath, filePath);
                if (File.Exists(fullDrPath))
                {
                    var memoryStream = new MemoryStream();
                    using (var fileStream = new FileStream(fullDrPath, FileMode.Open, FileAccess.Read))
                    {
                        await fileStream.CopyToAsync(memoryStream);
                    }
                    memoryStream.Position = 0;
                    return memoryStream;
                }
            }

            throw new FileNotFoundException("The specified file was not found", filePath);
        }

        public Task<bool> DeleteFileAsync(string filePath)
        {
            if (string.IsNullOrWhiteSpace(filePath))
                throw new ArgumentException("File path cannot be empty", nameof(filePath));

            var success = true;
            var fullPath = Path.Combine(_basePath, filePath);
            
            // Delete from primary location
            try
            {
                if (File.Exists(fullPath))
                {
                    File.Delete(fullPath);
                }
            }
            catch
            {
                success = false;
            }

            // If DR is enabled, delete from DR location
            if (_enableDrReplication)
            {
                try
                {
                    var fullDrPath = Path.Combine(_drBasePath, filePath);
                    if (File.Exists(fullDrPath))
                    {
                        File.Delete(fullDrPath);
                    }
                }
                catch
                {
                    // Log the error but don't fail the operation
                    success = false;
                }
            }

            return Task.FromResult(success);
        }

        public Task<bool> FileExistsAsync(string filePath)
        {
            if (string.IsNullOrWhiteSpace(filePath))
                return Task.FromResult(false);

            // Check primary location
            var fullPath = Path.Combine(_basePath, filePath);
            if (File.Exists(fullPath))
                return Task.FromResult(true);

            // If not found in primary and DR is enabled, check DR location
            if (_enableDrReplication)
            {
                var fullDrPath = Path.Combine(_drBasePath, filePath);
                return Task.FromResult(File.Exists(fullDrPath));
            }

            return Task.FromResult(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    // Dispose managed state (managed objects).
                }

                _disposed = true;
            }
        }
    }
}
