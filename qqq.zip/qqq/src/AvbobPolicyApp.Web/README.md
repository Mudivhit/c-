# Avbob Policy Management System - Frontend

## Overview
Angular-based frontend application for the Avbob Policy Management System. This application provides a user interface for managing policy holders and their insurance policies.

## Prerequisites
- Node.js (v16 or later)
- npm (v8 or later) or Yarn
- Angular CLI (v15 or later)
- Backend API (see [Backend README](../README.md) for setup)

## Getting Started

### 1. Clone the Repository
```bash
git clone [repository-url]
cd AvbobPolicyApp/src/AvbobPolicyApp.Web
```

### 2. Install Dependencies
```bash
npm install
# or
yarn install
```

### 3. Configure Environment
Update the API base URL in `src/environments/environment.ts`:
```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:5000/api'
};
```

### 4. Run the Development Server
```bash
ng serve
```
The application will be available at `http://localhost:4200`

## Project Structure

```
src/
├── app/                    # Application source code
│   ├── components/         # Reusable UI components
│   ├── core/               # Core module with services and guards
│   │   ├── config/         # Configuration files
│   │   ├── services/       # API services
│   │   └── interceptors/   # HTTP interceptors
│   ├── models/             # TypeScript interfaces and types
│   └── shared/             # Shared modules and components
├── assets/                 # Static assets (images, styles, etc.)
└── environments/           # Environment configurations
```

## Available Scripts

- `ng serve` - Start the development server
- `ng build` - Build the application for production
- `ng test` - Run unit tests
- `ng e2e` - Run end-to-end tests

## API Integration

The application communicates with the backend API using the following services:

### Policy Service
- `getPolicies()` - Fetch all policies
- `getPolicy(id)` - Get policy by ID
- `getPolicyByNumber(number)` - Get policy by policy number
- `createPolicy(policy)` - Create a new policy
- `updatePolicy(id, policy)` - Update an existing policy
- `deletePolicy(id)` - Delete a policy
- `uploadPolicyDocument(policyId, file)` - Upload a document for a policy

### Policy Holder Service
- `getPolicyHolder(id)` - Get policy holder by ID
- `getPolicyHolderByIdNumber(idNumber)` - Get policy holder by ID number
- `createPolicyHolder(policyHolder)` - Create a new policy holder
- `updatePolicyHolder(id, updates)` - Update a policy holder
- `deletePolicyHolder(id)` - Delete a policy holder
- `searchPolicyHolders(term)` - Search for policy holders

## Environment Configuration

### Development
Configuration for development environment is in `src/environments/environment.ts`

## Dependencies

- Angular 15
- Bootstrap 5
- ng-bootstrap
- Bootstrap Icons
- RxJS

## Backend Integration

This frontend is designed to work with a RESTful API. Update the API endpoints in the services to connect to your backend.

## License

This project is licensed under the MIT License.
