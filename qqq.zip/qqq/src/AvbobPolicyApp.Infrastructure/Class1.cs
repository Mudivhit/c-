﻿namespace AvbobPolicyApp.Infrastructure;

public class Class1
{

}
