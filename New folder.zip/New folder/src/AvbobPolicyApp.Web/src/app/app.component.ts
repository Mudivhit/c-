import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Policy } from './models/policy.model';
import { PolicyHolder } from './models/policy-holder.model';
import { PolicyHolderService } from './core/services/policy-holder.service';
import { PolicyService } from './core/services/policy.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'Policy Management System';
  policies: Policy[] = [];
  selectedPolicy: Policy | null = null;
  isEditing = false;
  currentPolicyHolder: PolicyHolder | null = null;
  isLoading = false;

  constructor(
    private policyHolderService: PolicyHolderService,
    private policyService: PolicyService,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    // Load initial data if needed
  }

  onPolicyHolderSelected(policyHolder: PolicyHolder) {
    this.currentPolicyHolder = policyHolder;
    this.loadPolicies(policyHolder.id!);
  }

  onSavePolicyHolder(policyHolderData: Partial<PolicyHolder>) {
    this.isLoading = true;
    
    if (this.currentPolicyHolder?.id) {
      // Update existing policy holder
      this.policyHolderService.updatePolicyHolder(
        this.currentPolicyHolder.id, 
        policyHolderData
      ).subscribe({
        next: (updatedPolicyHolder) => {
          this.currentPolicyHolder = updatedPolicyHolder;
          this.toastr.success('Policy holder updated successfully');
          this.loadPolicies(updatedPolicyHolder.id!);
        },
        error: (error) => {
          console.error('Error updating policy holder:', error);
          this.toastr.error('Failed to update policy holder');
        },
        complete: () => this.isLoading = false
      });
    } else {
      // Create new policy holder
      this.policyHolderService.createPolicyHolder(policyHolderData).subscribe({
        next: (newPolicyHolder) => {
          this.currentPolicyHolder = newPolicyHolder;
          this.toastr.success('Policy holder created successfully');
          this.loadPolicies(newPolicyHolder.id!);
        },
        error: (error) => {
          console.error('Error creating policy holder:', error);
          this.toastr.error('Failed to create policy holder');
        },
        complete: () => this.isLoading = false
      });
    }
  }

  private loadPolicies(policyHolderId: number) {
    if (!policyHolderId) return;
    
    this.isLoading = true;
    this.policyService.getPoliciesByHolderId(policyHolderId).subscribe({
      next: (policies) => {
        this.policies = policies;
      },
      error: (error) => {
        console.error('Error loading policies:', error);
        this.toastr.error('Failed to load policies');
        this.policies = [];
      },
      complete: () => this.isLoading = false
    });
  }

  onAddPolicy() {
    if (!this.currentPolicyHolder?.id) {
      this.toastr.warning('Please save the policy holder details first');
      return;
    }
    
    this.selectedPolicy = {
      policyNumber: '',
      policyType: '',
      installment: 0,
      commencementDate: new Date(),
      policyHolderId: this.currentPolicyHolder.id
    };
    this.isEditing = true;
  }

  onSelectPolicy(policy: Policy) {
    this.policyService.getPolicy(policy.id!).subscribe({
      next: (policyDetails) => {
        this.selectedPolicy = policyDetails;
        this.isEditing = true;
      },
      error: (error) => {
        console.error('Error loading policy details:', error);
        this.toastr.error('Failed to load policy details');
      }
    });
  }

  onSavePolicy(policy: Policy) {
    if (!this.currentPolicyHolder?.id) {
      this.toastr.warning('No policy holder selected');
      return;
    }

    this.isLoading = true;
    
    const policyData = {
      ...policy,
      policyHolderId: this.currentPolicyHolder.id
    };

    if (policy.id) {
      // For update, we don't get the updated policy back, so we'll reload the list
      this.policyService.updatePolicy(policy.id, policyData).subscribe({
        next: () => {
          this.toastr.success('Policy updated successfully');
          this.loadPolicies(this.currentPolicyHolder!.id!);
          this.isEditing = false;
          this.selectedPolicy = null;
          this.isLoading = false;
        },
        error: (error: any) => {
          console.error('Error updating policy:', error);
          this.toastr.error('Failed to update policy');
          this.isLoading = false;
        }
      });
    } else {
      // For create, we get the created policy back
      this.policyService.createPolicy(policyData).subscribe({
        next: (savedPolicy: Policy) => {
          this.toastr.success('Policy created successfully');
          this.loadPolicies(this.currentPolicyHolder!.id!);
          this.isEditing = false;
          this.selectedPolicy = null;
          this.isLoading = false;
        },
        error: (error: any) => {
          console.error('Error creating policy:', error);
          this.toastr.error('Failed to create policy');
          this.isLoading = false;
        }
      });
    }
  }

  onCancelEdit() {
    this.selectedPolicy = null;
    this.isEditing = false;
  }
}
