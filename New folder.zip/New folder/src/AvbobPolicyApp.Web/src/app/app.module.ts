import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { PolicyHolderDetailsComponent } from './components/policy-holder-details/policy-holder-details.component';
import { PolicyListComponent } from './components/policy-list/policy-list.component';
import { PolicyDetailsComponent } from './components/policy-details/policy-details.component';
import { PolicyHolderService } from './core/services/policy-holder.service';
import { PolicyService } from './core/services/policy.service';

@NgModule({
  declarations: [
    AppComponent,
    PolicyHolderDetailsComponent,
    PolicyListComponent,
    PolicyDetailsComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgbModule,
    ToastrModule.forRoot({
      positionClass: 'toast-top-right',
      timeOut: 5000,
      closeButton: true,
      progressBar: true
    })
  ],
  providers: [
    PolicyHolderService,
    PolicyService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
