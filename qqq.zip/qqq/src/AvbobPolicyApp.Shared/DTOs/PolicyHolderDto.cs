using System.ComponentModel.DataAnnotations;

namespace AvbobPolicyApp.Shared.DTOs
{
    public class PolicyHolderDto
    {
        public int Id { get; set; }
        
        [Required(ErrorMessage = "ID Number is required")]
        [StringLength(13, MinimumLength = 13, ErrorMessage = "ID Number must be 13 digits")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "ID Number must contain only numbers")]
        public string IDNumber { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "Initials are required")]
        [StringLength(10, ErrorMessage = "Initials cannot exceed 10 characters")]
        public string Initials { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "Surname is required")]
        [StringLength(50, ErrorMessage = "Surname cannot exceed 50 characters")]
        public string Surname { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "Date of Birth is required")]
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }
        
        [Required(ErrorMessage = "Gender is required")]
        public string Gender { get; set; } = string.Empty;
    }
}
