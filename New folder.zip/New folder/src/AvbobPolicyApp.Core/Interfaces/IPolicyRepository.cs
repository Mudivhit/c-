using AvbobPolicyApp.Core.Entities;

namespace AvbobPolicyApp.Core.Interfaces
{
    public interface IPolicyRepository : IRepository<Policy>
    {
        Task<IEnumerable<Policy>> GetPoliciesByHolderIdAsync(int holderId);
        Task<Policy?> GetByPolicyNumberAsync(string policyNumber);
    }
}
