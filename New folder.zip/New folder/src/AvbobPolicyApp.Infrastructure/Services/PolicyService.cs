using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using AutoMapper;
using AvbobPolicyApp.Core.Entities;
using AvbobPolicyApp.Core.Interfaces;
using Microsoft.Extensions.Configuration;

namespace AvbobPolicyApp.Infrastructure.Services
{
    public class PolicyService : IPolicyService
    {
        private readonly IPolicyRepository _policyRepository;
        private readonly IPolicyHolderRepository _policyHolderRepository;
        private readonly IMapper _mapper;
        private readonly IFileStorageService _fileStorageService;
        private readonly IConfiguration _configuration;

        public PolicyService(
            IPolicyRepository policyRepository,
            IPolicyHolderRepository policyHolderRepository,
            IMapper mapper,
            IFileStorageService fileStorageService,
            IConfiguration configuration)
        {
            _policyRepository = policyRepository ?? throw new ArgumentNullException(nameof(policyRepository));
            _policyHolderRepository = policyHolderRepository ?? throw new ArgumentNullException(nameof(policyHolderRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _fileStorageService = fileStorageService ?? throw new ArgumentNullException(nameof(fileStorageService));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public async Task<IEnumerable<Policy>> GetPoliciesByHolderIdAsync(int holderId)
        {
            // If holderId is 0, get all policies, otherwise filter by holderId
            if (holderId == 0)
            {
                return await _policyRepository.GetAllAsync();
            }
            return await _policyRepository.FindAsync(p => p.PolicyHolderId == holderId);
        }

        public async Task<Policy> GetPolicyByIdAsync(int id)
        {
            return await _policyRepository.GetByIdAsync(id);
        }

        public async Task<Policy> GetPolicyByNumberAsync(string policyNumber)
        {
            if (string.IsNullOrWhiteSpace(policyNumber))
                throw new ArgumentException("Policy number cannot be null or whitespace.", nameof(policyNumber));
                
            var policies = await _policyRepository.FindAsync(p => p.PolicyNumber == policyNumber);
            return policies.FirstOrDefault();
        }

        public async Task<Policy> CreatePolicyAsync(Policy policy)
        {
            if (policy == null)
                throw new ArgumentNullException(nameof(policy));

            await _policyRepository.AddAsync(policy);
            await _policyRepository.SaveChangesAsync();
            
            return policy;
        }

        public async Task<bool> UpdatePolicyAsync(int id, Policy policy)
        {
            if (policy == null)
                throw new ArgumentNullException(nameof(policy));

            var existingPolicy = await _policyRepository.GetByIdAsync(id);
            if (existingPolicy == null)
                return false;

            // Update the existing policy with the new values
            _mapper.Map(policy, existingPolicy);
            
            _policyRepository.Update(existingPolicy);
            return await _policyRepository.SaveChangesAsync();
        }

        public async Task<bool> DeletePolicyAsync(int id)
        {
            var policy = await _policyRepository.GetByIdAsync(id);
            if (policy == null)
                return false;

            _policyRepository.Remove(policy);
            return await _policyRepository.SaveChangesAsync();
        }

        public async Task<string> UploadPolicyDocumentAsync(int policyId, string fileName, Stream fileStream)
        {
            if (fileStream == null || fileStream.Length == 0)
                throw new ArgumentException("File stream is empty", nameof(fileStream));

            var policy = await _policyRepository.GetByIdAsync(policyId);
            if (policy == null)
                throw new KeyNotFoundException($"Policy with ID {policyId} not found");

            // Save the file to the storage service
            var folderPath = $"policies/{policyId}";
            var filePath = await _fileStorageService.SaveFileAsync(folderPath, fileName, fileStream);
            
            // Update the policy with the document path if needed
            // For example, if you have a DocumentPath property on the Policy entity
            // policy.DocumentPath = filePath;
            // await _policyRepository.UnitOfWork.SaveEntitiesAsync();
            
            return filePath;
        }

        public async Task<Stream> DownloadPolicyDocumentAsync(int policyId, string fileName)
        {
            var policy = await _policyRepository.GetByIdAsync(policyId);
            if (policy == null)
                throw new KeyNotFoundException($"Policy with ID {policyId} not found");

            // Get the file stream from storage service
            var filePath = $"policies/{policyId}/{fileName}";
            return await _fileStorageService.GetFileAsync(filePath);
        }

        public async Task<bool> DeletePolicyDocumentAsync(int policyId, string fileName)
        {
            var policy = await _policyRepository.GetByIdAsync(policyId);
            if (policy == null)
                throw new KeyNotFoundException($"Policy with ID {policyId} not found");

            // Delete the file from storage service
            var filePath = $"policies/{policyId}/{fileName}";
            return await _fileStorageService.DeleteFileAsync(filePath);
        }
    }
}
