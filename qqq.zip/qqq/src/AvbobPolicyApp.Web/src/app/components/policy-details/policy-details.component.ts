import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Policy } from '../../models/policy.model';

@Component({
  selector: 'app-policy-details',
  templateUrl: './policy-details.component.html',
  styleUrls: ['./policy-details.component.scss']
})
export class PolicyDetailsComponent implements OnChanges {
  @Input() policy: Policy | null = null;
  @Output() save = new EventEmitter<Policy>();
  @Output() cancel = new EventEmitter<void>();

  form: FormGroup;
  policyTypes = [
    'Life Insurance',
    'Funeral Cover',
    'Endowment',
    'Retirement Annuity'
  ];

  selectedFile: File | null = null;

  constructor(private fb: FormBuilder) {
    this.form = this.fb.group({
      policyNumber: ['', [Validators.required, Validators.pattern('^[A-Z0-9-]+$')]],
      policyType: ['', Validators.required],
      commencementDate: ['', Validators.required],
      installment: [0, [Validators.required, Validators.min(0)]]
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['policy'] && this.policy) {
      this.form.patchValue({
        policyNumber: this.policy.policyNumber,
        policyType: this.policy.policyType,
        commencementDate: this.policy.commencementDate || '',
        installment: this.policy.installment
      });
    } else if (!this.policy) {
      this.form.reset();
      this.selectedFile = null;
    }
  }

  onFileSelected(event: any) {
    const file: File = event.target.files[0];
    if (file) {
      this.selectedFile = file;
    }
  }

  onSubmit() {
    if (this.form.valid) {
      const formData = new FormData();
      const policyData = this.form.value;
      
      // Append form data
      Object.keys(policyData).forEach(key => {
        formData.append(key, policyData[key]);
      });
      
      // Append file if selected
      if (this.selectedFile) {
        formData.append('applicationForm', this.selectedFile);
      }
      
      this.save.emit({
        ...this.policy,
        ...policyData,
        commencementDate: new Date(policyData.commencementDate)
      });
    } else {
      // Mark all fields as touched to show validation messages
      Object.keys(this.form.controls).forEach(key => {
        this.form.get(key)?.markAsTouched();
      });
    }
  }

  onCancel() {
    this.cancel.emit();
  }
}
