using System;
using System.Collections.Generic;

namespace AvbobPolicyApp.Core.Entities
{
    public class PolicyHolder
    {
        public int Id { get; set; }
        public string IDNumber { get; set; } = string.Empty;
        public string Initials { get; set; } = string.Empty;
        public string Surname { get; set; } = string.Empty;
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; } = string.Empty;
        
        // Navigation property
        public ICollection<Policy> Policies { get; set; } = new List<Policy>();
    }
}
