using System.Collections.Generic;
using System.Threading.Tasks;
using AvbobPolicyApp.Core.Entities;

namespace AvbobPolicyApp.Core.Interfaces
{
    public interface IPolicyHolderService
    {
        Task<IEnumerable<PolicyHolder>> GetAllPolicyHoldersAsync();
        Task<PolicyHolder> GetPolicyHolderByIdAsync(int id);
        Task<PolicyHolder> GetPolicyHolderByIdNumberAsync(string idNumber);
        Task<IEnumerable<Policy>> GetPoliciesByHolderIdAsync(int holderId);
        Task<IEnumerable<PolicyHolder>> SearchPolicyHoldersAsync(string searchTerm);
        Task<PolicyHolder> CreatePolicyHolderAsync(PolicyHolder policyHolder);
        Task<bool> UpdatePolicyHolderAsync(int id, PolicyHolder policyHolder);
        Task<bool> DeletePolicyHolderAsync(int id);
        Task<bool> PolicyHolderHasPoliciesAsync(int policyHolderId);
    }
}
