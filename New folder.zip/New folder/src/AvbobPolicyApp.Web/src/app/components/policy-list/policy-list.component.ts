import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Policy } from '../../models/policy.model';

@Component({
  selector: 'app-policy-list',
  templateUrl: './policy-list.component.html',
  styleUrls: ['./policy-list.component.scss']
})
export class PolicyListComponent {
  @Input() policies: Policy[] = [];
  @Output() selectPolicy = new EventEmitter<Policy>();

  onSelect(policy: Policy) {
    this.selectPolicy.emit(policy);
  }
}
