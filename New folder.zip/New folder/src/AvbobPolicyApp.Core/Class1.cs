﻿namespace AvbobPolicyApp.Core;

public class Class1
{

}
