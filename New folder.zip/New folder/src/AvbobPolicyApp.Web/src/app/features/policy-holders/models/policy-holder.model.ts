/**
 * Represents a policy holder in the system
 */
export interface PolicyHolder {
  /** Unique identifier for the policy holder */
  id: number;
  
  /** Title of the policy holder (e.g., Mr, Mrs, Dr) */
  title?: string;
  
  /** Initials of the policy holder */
  initials: string;
  
  /** Surname of the policy holder */
  surname: string;
  
  /** Full name of the policy holder (concatenation of title, initials, and surname) */
  fullName: string;
  
  /** ID number of the policy holder */
  idNumber: string;
  
  /** Date of birth of the policy holder */
  dateOfBirth?: Date;
  
  /** Gender of the policy holder (M/F/Other) */
  gender?: string;
  
  /** Contact email address */
  email?: string;
  
  /** Contact phone number */
  phoneNumber?: string;
  
  /** Physical address */
  address?: {
    line1: string;
    line2?: string;
    city: string;
    postalCode: string;
    country: string;
  };
  
  /** Whether the policy holder is active */
  isActive: boolean;
  
  /** Date when the policy holder was created */
  createdOn: Date;
  
  /** Last modified date */
  modifiedOn?: Date;
  
  /** Any additional notes */
  notes?: string;
  
  /** Number of active policies for this holder */
  policyCount?: number;
}

/**
 * Represents a summary of a policy holder for listing
 */
export interface PolicyHolderSummary {
  id: number;
  fullName: string;
  idNumber: string;
  email?: string;
  phoneNumber?: string;
  policyCount: number;
  isActive: boolean;
}

/**
 * Request payload for creating or updating a policy holder
 */
export interface PolicyHolderRequest {
  title?: string;
  initials: string;
  surname: string;
  idNumber: string;
  dateOfBirth?: string | Date;
  gender?: string;
  email?: string;
  phoneNumber?: string;
  address?: {
    line1: string;
    line2?: string;
    city: string;
    postalCode: string;
    country: string;
  };
  isActive?: boolean;
  notes?: string;
}

/**
 * Response from searching policy holders
 */
export interface PolicyHolderSearchResponse {
  items: PolicyHolderSummary[];
  pagination: {
    currentPage: number;
    pageSize: number;
    totalCount: number;
    totalPages: number;
    searchTerm?: string;
  };
}
