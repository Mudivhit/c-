using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AvbobPolicyApp.Core.Entities;

namespace AvbobPolicyApp.Core.Interfaces
{
    public interface IPolicyService
    {
        Task<IEnumerable<Policy>> GetPoliciesByHolderIdAsync(int holderId);
        Task<Policy> GetPolicyByIdAsync(int id);
        Task<Policy> GetPolicyByNumberAsync(string policyNumber);
        Task<Policy> CreatePolicyAsync(Policy policy);
        Task<bool> UpdatePolicyAsync(int id, Policy policy);
        Task<bool> DeletePolicyAsync(int id);
        Task<string> UploadPolicyDocumentAsync(int policyId, string fileName, Stream fileStream);
        Task<Stream> DownloadPolicyDocumentAsync(int policyId, string fileName);
        Task<bool> DeletePolicyDocumentAsync(int policyId, string fileName);
    }
}
