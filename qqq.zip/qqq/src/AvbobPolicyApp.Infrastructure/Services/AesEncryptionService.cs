using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using AvbobPolicyApp.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace AvbobPolicyApp.Infrastructure.Services
{
    public class AesEncryptionService : IEncryptionService, IDisposable
    {
        private readonly byte[] _key;
        private readonly ILogger<AesEncryptionService> _logger;
        private readonly Aes _aes;
        private bool _disposed = false;

        public AesEncryptionService(string key, ILogger<AesEncryptionService> logger = null)
        {
            if (string.IsNullOrEmpty(key))
                throw new ArgumentException("Encryption key cannot be null or empty", nameof(key));

            // Ensure the key is the correct size (16, 24, or 32 bytes for AES)
            using var sha256 = SHA256.Create();
            _key = sha256.ComputeHash(Encoding.UTF8.GetBytes(key))[..32]; // Take first 32 bytes for AES-256
            
            _logger = logger;
            _aes = Aes.Create() ?? throw new InvalidOperationException("Failed to create AES instance");
            _aes.Key = _key;
            _aes.Mode = CipherMode.CBC;
            _aes.Padding = PaddingMode.PKCS7;
        }

        public string Encrypt(string plainText)
        {
            if (string.IsNullOrEmpty(plainText))
                return plainText;

            if (_disposed)
                throw new ObjectDisposedException(nameof(AesEncryptionService));

            try
            {
                _aes.GenerateIV();
                using var encryptor = _aes.CreateEncryptor(_aes.Key, _aes.IV);
                
                using var msEncrypt = new MemoryStream();
                // Write IV first (16 bytes)
                msEncrypt.Write(_aes.IV, 0, _aes.IV.Length);
                
                using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                using (var swEncrypt = new StreamWriter(csEncrypt, Encoding.UTF8))
                {
                    swEncrypt.Write(plainText);
                }

                return Convert.ToBase64String(msEncrypt.ToArray());
            }
            catch (Exception ex) when (ex is not InvalidOperationException)
            {
                _logger?.LogError(ex, "Error encrypting data");
                throw new InvalidOperationException("Failed to encrypt data", ex);
            }
        }

        public string Decrypt(string cipherText)
        {
            if (string.IsNullOrEmpty(cipherText))
                return cipherText;

            if (_disposed)
                throw new ObjectDisposedException(nameof(AesEncryptionService));

            try
            {
                var fullCipher = Convert.FromBase64String(cipherText);
                
                // Check if the cipher text is too short to contain IV + encrypted data
                if (fullCipher.Length < 16)
                    throw new ArgumentException("Invalid cipher text format");
                
                // Extract IV (first 16 bytes)
                var iv = new byte[16];
                var cipherBytes = new byte[fullCipher.Length - iv.Length];
                
                Buffer.BlockCopy(fullCipher, 0, iv, 0, iv.Length);
                Buffer.BlockCopy(fullCipher, iv.Length, cipherBytes, 0, cipherBytes.Length);
                
                using var decryptor = _aes.CreateDecryptor(_key, iv);
                using var msDecrypt = new MemoryStream(cipherBytes);
                using var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read);
                using var srDecrypt = new StreamReader(csDecrypt, Encoding.UTF8);
                
                return srDecrypt.ReadToEnd();
            }
            catch (Exception ex) when (ex is not InvalidOperationException)
            {
                _logger?.LogError(ex, "Error decrypting data");
                throw new InvalidOperationException("Failed to decrypt data", ex);
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _aes?.Dispose();
                }
                _disposed = true;
            }
        }

        ~AesEncryptionService()
        {
            Dispose(false);
        }
    }
}
