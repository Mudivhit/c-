﻿namespace AvbobPolicyApp.Shared;

public class Class1
{

}
