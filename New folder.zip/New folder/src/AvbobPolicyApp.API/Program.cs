using System.Text.Json.Serialization;
using AutoMapper;
using AvbobPolicyApp.Core.Interfaces;
using AvbobPolicyApp.Infrastructure.Data;
using AvbobPolicyApp.Infrastructure.Repositories;
using AvbobPolicyApp.Infrastructure.Services;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;

var builder = WebApplication.CreateBuilder(args);

// Add AutoMapper
builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

// Add logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

// Add services to the container.
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });

// Configure CORS
var corsOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? Array.Empty<string>();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigins",
        policy =>
        {
            if (corsOrigins.Length > 0)
            {
                policy.WithOrigins(corsOrigins)
                      .AllowAnyMethod()
                      .AllowAnyHeader()
                      .AllowCredentials();
            }
            else
            {
                // Fallback to AllowAnyOrigin if no specific origins are configured
                policy.AllowAnyOrigin()
                      .AllowAnyMethod()
                      .AllowAnyHeader();
            }
        });
});

// Configure Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "AVBOB Policy API", Version = "v1" });
});

// Register repositories
builder.Services.AddScoped<IPolicyRepository, PolicyRepository>();
builder.Services.AddScoped<IPolicyHolderRepository, PolicyHolderRepository>();

// Register application services
builder.Services.AddScoped<IPolicyService, PolicyService>();
builder.Services.AddScoped<IPolicyHolderService>(provider => 
    new PolicyHolderService(
        provider.GetRequiredService<IPolicyHolderRepository>(),
        provider.GetRequiredService<IPolicyService>(),
        provider.GetRequiredService<IMapper>(),
        provider.GetRequiredService<IEncryptionService>()));

// Register file storage and encryption services with configuration
var fileStoragePath = builder.Configuration["FileStorage:Path"] ?? "App_Data/Uploads";
var encryptionKey = builder.Configuration["Encryption:Key"] ?? "DefaultEncryptionKey1234567890123456";

// Ensure the upload directory exists
var fullStoragePath = Path.Combine(builder.Environment.ContentRootPath, fileStoragePath);
Directory.CreateDirectory(fullStoragePath);

// Register file storage service
builder.Services.AddScoped<IFileStorageService>(sp => 
    new LocalFileStorageService(
        fileStoragePath, 
        sp.GetRequiredService<ILogger<LocalFileStorageService>>()));
    
// Register encryption service
builder.Services.AddScoped<IEncryptionService>(sp => 
    new AesEncryptionService(
        encryptionKey, 
        sp.GetRequiredService<ILogger<AesEncryptionService>>()));

// Register repositories
builder.Services.AddScoped<IPolicyRepository, PolicyRepository>();
builder.Services.AddScoped<IPolicyHolderRepository, PolicyHolderRepository>();

// Configure Database Context
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection") ?? 
        throw new InvalidOperationException("Connection string 'DefaultConnection' not found."),
        sqlOptions =>
        {
            sqlOptions.MigrationsAssembly(typeof(AppDbContext).Assembly.FullName);
            sqlOptions.EnableRetryOnFailure(
                maxRetryCount: 5,
                maxRetryDelay: TimeSpan.FromSeconds(30),
                errorNumbersToAdd: null);
        }));

// Configure Data Protection
var dataProtectionPath = Path.Combine(builder.Environment.ContentRootPath, "DataProtection-Keys");
Directory.CreateDirectory(dataProtectionPath);

builder.Services.AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(dataProtectionPath))
    .SetApplicationName("AvbobPolicyApp");

// Configure AutoMapper
builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/error");
    app.UseHsts();
}

// Enable middleware to serve generated Swagger as a JSON endpoint
app.UseSwagger();

// Enable middleware to serve swagger-ui
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "AVBOB Policy API v1");
    c.RoutePrefix = string.Empty; // Serve the Swagger UI at the root
});

// Use CORS with the specified policy
app.UseCors("AllowSpecificOrigins");

// Configure HTTPS redirection if enabled
var requireHttps = builder.Configuration.GetValue<bool>("Security:RequireHttps", true);
if (requireHttps)
{
    app.UseHttpsRedirection();
}

// Configure HSTS if enabled
var hstsEnabled = builder.Configuration.GetValue<bool>("Security:Hsts:Enabled", true);
if (hstsEnabled && !app.Environment.IsDevelopment())
{
    var maxAgeDays = builder.Configuration.GetValue<int>("Security:Hsts:MaxAgeDays", 30);
    var maxAge = TimeSpan.FromDays(maxAgeDays);
    
    app.UseHsts();
    
    // Add HSTS header manually with options
    app.Use(async (context, next) =>
    {
        if (context.Request.IsHttps)
        {
            var maxAgeSeconds = (int)maxAge.TotalSeconds;
            var includeSubDomains = builder.Configuration.GetValue<bool>("Security:Hsts:IncludeSubDomains", false) ? "; includeSubDomains" : "";
            var preload = builder.Configuration.GetValue<bool>("Security:Hsts:Preload", false) ? "; preload" : "";
            
            context.Response.Headers.Add("Strict-Transport-Security", 
                $"max-age={maxAgeSeconds}{includeSubDomains}{preload}");
        }
        await next();
    });
}

// Configure static files
app.UseStaticFiles();

// Configure routing
app.UseRouting();

// Authentication & Authorization
app.UseAuthentication();
app.UseAuthorization();

// Map controllers
app.MapControllers();

// Fallback to index.html for SPA routing
app.MapFallbackToFile("index.html");

// Apply migrations and run the app
try
{
    using var scope = app.Services.CreateScope();
    var services = scope.ServiceProvider;
    
    var logger = services.GetRequiredService<ILogger<Program>>();
    var context = services.GetRequiredService<AppDbContext>();
    
    logger.LogInformation("Applying database migrations...");
    await context.Database.MigrateAsync();
    logger.LogInformation("Database migrations applied successfully.");
    
    app.Run();
}
catch (Exception ex)
{
    var logger = app.Services.GetRequiredService<ILogger<Program>>();
    logger.LogError(ex, "An error occurred while starting the application");
    throw;
}
