using System.Linq.Expressions;
using AvbobPolicyApp.Core.Entities;
using AvbobPolicyApp.Core.Interfaces;
using AvbobPolicyApp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace AvbobPolicyApp.Infrastructure.Repositories
{
    public class PolicyHolderRepository : Repository<PolicyHolder>, IPolicyHolderRepository
    {
        private readonly AppDbContext _context;

        public PolicyHolderRepository(AppDbContext context) : base(context)
        {
            _context = context;
        }

        public async Task<PolicyHolder?> GetByIDNumberAsync(string idNumber)
        {
            return await _context.PolicyHolders
                .FirstOrDefaultAsync(ph => ph.IDNumber == idNumber);
        }

        public async Task<IEnumerable<Policy>> GetPoliciesByHolderIdAsync(int holderId)
        {
            return await _context.Policies
                .Where(p => p.PolicyHolderId == holderId)
                .ToListAsync();
        }

        public async Task<IEnumerable<PolicyHolder>> SearchAsync(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
                return await GetAllAsync();

            var normalizedSearchTerm = searchTerm.Trim().ToLower();
            
            return await _context.PolicyHolders
                .Where(ph => 
                    ph.IDNumber.ToLower().Contains(normalizedSearchTerm) ||
                    ph.Initials.ToLower().Contains(normalizedSearchTerm) ||
                    ph.Surname.ToLower().Contains(normalizedSearchTerm))
                .ToListAsync();
        }
    }
}
