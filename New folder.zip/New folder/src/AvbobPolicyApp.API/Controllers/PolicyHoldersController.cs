using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AvbobPolicyApp.Core.Entities;
using AvbobPolicyApp.Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Linq;

namespace AvbobPolicyApp.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PolicyHoldersController : BaseApiController
    {
        private readonly IPolicyHolderService _policyHolderService;
        private readonly ILogger<PolicyHoldersController> _logger;

        public PolicyHoldersController(
            IPolicyHolderService policyHolderService,
            ILogger<PolicyHoldersController> logger) : base(logger)
        {
            _policyHolderService = policyHolderService ?? throw new ArgumentNullException(nameof(policyHolderService));
            _logger = logger;
        }

        // GET: api/policyholders
        /// <summary>
        /// Gets all policy holders with optional pagination and search
        /// </summary>
        /// <param name="searchTerm">Optional search term to filter policy holders</param>
        /// <param name="pageNumber">Page number for pagination (default: 1)</param>
        /// <param name="pageSize">Number of items per page (default: 20, max: 100)</param>
        /// <returns>List of policy holders</returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetPolicyHolders(
            [FromQuery] string searchTerm = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 20)
        {
            if (pageNumber < 1) pageNumber = 1;
            if (pageSize < 1 || pageSize > 100) pageSize = 20;

            try
            {
                IEnumerable<PolicyHolder> policyHolders;
                
                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    policyHolders = await _policyHolderService.SearchPolicyHoldersAsync(searchTerm);
                }
                else
                {
                    policyHolders = await _policyHolderService.GetAllPolicyHoldersAsync();
                }

                // Apply pagination
                var paginatedPolicyHolders = policyHolders
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToList();

                // Add pagination headers
                Response.Headers["X-Pagination"] = 
                    System.Text.Json.JsonSerializer.Serialize(new 
                    { 
                        TotalCount = policyHolders.Count(),
                        PageSize = pageSize,
                        CurrentPage = pageNumber,
                        TotalPages = (int)Math.Ceiling(policyHolders.Count() / (double)pageSize),
                        SearchTerm = searchTerm
                    });

                return Ok(paginatedPolicyHolders);
            }
            catch (Exception ex)
            {
                return HandleException(ex, "An error occurred while retrieving policy holders");
            }
        }

        // GET: api/policyholders/5
        /// <summary>
        /// Gets a policy holder by ID
        /// </summary>
        /// <param name="id">The ID of the policy holder to retrieve</param>
        /// <returns>The requested policy holder</returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetPolicyHolder(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid policy holder ID");
            }

            try
            {
                var policyHolder = await _policyHolderService.GetPolicyHolderByIdAsync(id);
                return HandleResult(policyHolder, $"Policy holder with ID {id} not found");
            }
            catch (Exception ex)
            {
                return HandleException(ex, $"Error retrieving policy holder with ID {id}");
            }
        }

        // GET: api/policyholders/idnumber/1234567890123
        [HttpGet("idnumber/{idNumber}")]
        public async Task<IActionResult> GetPolicyHolderByIdNumber(string idNumber)
        {
            try
            {
                var policyHolder = await _policyHolderService.GetPolicyHolderByIdNumberAsync(idNumber);
                return HandleResult(policyHolder, $"Policy holder with ID number {idNumber} not found");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving policy holder with ID number {idNumber}");
                return HandleException(ex, $"An error occurred while retrieving policy holder with ID number {idNumber}");
            }
        }

        // GET: api/policyholders/5/policies
        /// <summary>
        /// Gets all policies for a specific policy holder
        /// </summary>
        /// <param name="id">The ID of the policy holder</param>
        /// <param name="pageNumber">Page number for pagination (default: 1)</param>
        /// <param name="pageSize">Number of items per page (default: 20, max: 100)</param>
        /// <returns>List of policies for the specified policy holder</returns>
        [HttpGet("{id}/policies")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetPoliciesForPolicyHolder(
            int id,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 20)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid policy holder ID");
            }

            if (pageNumber < 1) pageNumber = 1;
            if (pageSize < 1 || pageSize > 100) pageSize = 20;

            try
            {
                // Check if policy holder exists
                var policyHolder = await _policyHolderService.GetPolicyHolderByIdAsync(id);
                if (policyHolder == null)
                {
                    return NotFound($"Policy holder with ID {id} not found");
                }

                var policies = await _policyHolderService.GetPoliciesByHolderIdAsync(id);
                
                // Apply pagination
                var paginatedPolicies = policies
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToList();

                // Add pagination headers
                Response.Headers["X-Pagination"] = 
                    System.Text.Json.JsonSerializer.Serialize(new 
                    { 
                        TotalCount = policies.Count(),
                        PageSize = pageSize,
                        CurrentPage = pageNumber,
                        TotalPages = (int)Math.Ceiling(policies.Count() / (double)pageSize),
                        PolicyHolderId = id
                    });

                return Ok(paginatedPolicies);
            }
            catch (Exception ex)
            {
                return HandleException(ex, $"Error retrieving policies for policy holder with ID {id}");
            }
        }

        // POST: api/policyholders
        /// <summary>
        /// Creates a new policy holder
        /// </summary>
        /// <param name="policyHolder">The policy holder to create</param>
        /// <returns>The created policy holder</returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreatePolicyHolder([FromBody] PolicyHolder policyHolder)
        {
            var validationResult = ValidateModelState();
            if (validationResult != null)
            {
                return validationResult;
            }

            try
            {
                var createdPolicyHolder = await _policyHolderService.CreatePolicyHolderAsync(policyHolder);
                return HandleCreatedResult(createdPolicyHolder, nameof(GetPolicyHolder), 
                    new { id = createdPolicyHolder?.Id }, "Failed to create policy holder");
            }
            catch (Exception ex)
            {
                return HandleException(ex, "Error creating policy holder");
            }
        }

        // PUT: api/policyholders/5
        /// <summary>
        /// Updates an existing policy holder
        /// </summary>
        /// <param name="id">The ID of the policy holder to update</param>
        /// <param name="policyHolder">The updated policy holder data</param>
        /// <returns>No content if successful</returns>
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UpdatePolicyHolder(int id, [FromBody] PolicyHolder policyHolder)
        {
            if (id != policyHolder?.Id)
            {
                return BadRequest("ID in route does not match ID in request body");
            }

            var validationResult = ValidateModelState();
            if (validationResult != null)
            {
                return validationResult;
            }


            try
            {
                var result = await _policyHolderService.UpdatePolicyHolderAsync(id, policyHolder);
                if (!result)
                {
                    return NotFound($"Policy holder with ID {id} not found");
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                return HandleException(ex, $"Error updating policy holder with ID {id}");
            }
        }

        // DELETE: api/policyholders/5
        /// <summary>
        /// Deletes a policy holder
        /// </summary>
        /// <param name="id">The ID of the policy holder to delete</param>
        /// <returns>No content if successful</returns>
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> DeletePolicyHolder(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid policy holder ID");
            }

            try
            {
                // Check if policy holder has any policies before deleting
                var hasPolicies = await _policyHolderService.PolicyHolderHasPoliciesAsync(id);
                if (hasPolicies)
                {
                    return BadRequest("Cannot delete policy holder with existing policies. Please delete the policies first.");
                }

                var result = await _policyHolderService.DeletePolicyHolderAsync(id);
                if (!result)
                {
                    return NotFound($"Policy holder with ID {id} not found");
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                return HandleException(ex, $"Error deleting policy holder with ID {id}");
            }
        }
    }
}
