import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { API_CONFIG } from '../config/api.config';
import { PolicyHolder, PolicyHolderSearchResult } from '../../models/policy-holder.model';
import { ApiResponse } from '../../models/policy.model';

@Injectable({
  providedIn: 'root'
})
export class PolicyHolderService {
  private readonly baseUrl = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.policyHolders.base}`;

  constructor(private http: HttpClient) {}

  // Create a new policy holder
  createPolicyHolder(policyHolder: Partial<PolicyHolder>): Observable<PolicyHolder> {
    return this.http.post<ApiResponse<PolicyHolder>>(this.baseUrl, policyHolder).pipe(
      map(response => response.data!)
    );
  }

  // Get policy holder by ID
  getPolicyHolder(id: number): Observable<PolicyHolder> {
    return this.http.get<ApiResponse<PolicyHolder>>(`${this.baseUrl}/${id}`).pipe(
      map(response => response.data!)
    );
  }

  // Update policy holder
  updatePolicyHolder(id: number, updates: Partial<PolicyHolder>): Observable<PolicyHolder> {
    return this.http.put<ApiResponse<PolicyHolder>>(`${this.baseUrl}/${id}`, updates).pipe(
      map(response => response.data!)
    );
  }

  // Delete policy holder
  deletePolicyHolder(id: number): Observable<boolean> {
    return this.http.delete<ApiResponse<boolean>>(`${this.baseUrl}/${id}`).pipe(
      map(response => response.success)
    );
  }

  // Search policy holders by ID number
  getPolicyHolderByIdNumber(idNumber: string): Observable<PolicyHolder> {
    return this.http.get<ApiResponse<PolicyHolder>>(
      `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.policyHolders.byIdNumber}/${idNumber}`
    ).pipe(
      map(response => response.data!)
    );
  }
  
  // Search policy holders by term
  searchPolicyHolders(term: string): Observable<PolicyHolderSearchResult[]> {
    if (!term || term.trim().length < 3) {
      return of([]);
    }
    
    return this.http.get<ApiResponse<PolicyHolderSearchResult[]>>(
      `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.policyHolders.search}?term=${encodeURIComponent(term)}`
    ).pipe(
      map(response => response.data || []),
      catchError(() => of([]))
    );
  }
}