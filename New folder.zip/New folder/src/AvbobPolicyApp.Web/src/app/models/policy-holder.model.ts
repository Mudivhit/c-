export interface PolicyHolder {
  id?: number;
  idNumber: string;
  initials: string;
  surname: string;
  dateOfBirth: string | Date;
  gender: string;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface PolicyHolderSearchResult {
  idNumber: string;
  fullName: string;
  initials: string;
  surname: string;
}
