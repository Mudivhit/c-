using System;

namespace AvbobPolicyApp.Core.Entities
{
    public class Policy
    {
        public int Id { get; set; }
        public string PolicyNumber { get; set; } = string.Empty;
        public string PolicyType { get; set; } = string.Empty;
        public DateTime CommencementDate { get; set; }
        public decimal Installment { get; set; }
        public string ApplicationFormPath { get; set; } = string.Empty;
        
        // Foreign key
        public int PolicyHolderId { get; set; }
        
        // Navigation property
        public PolicyHolder PolicyHolder { get; set; } = null!;
    }
}
