using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using AvbobPolicyApp.Core.Entities;
using AvbobPolicyApp.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace AvbobPolicyApp.Infrastructure.Services
{
    public class PolicyHolderService : IPolicyHolderService
    {
        private readonly IPolicyHolderRepository _policyHolderRepository;
        private readonly IPolicyService _policyService;
        private readonly IMapper _mapper;
        private readonly IEncryptionService _encryptionService;

        public PolicyHolderService(
            IPolicyHolderRepository policyHolderRepository,
            IPolicyService policyService,
            IMapper mapper,
            IEncryptionService encryptionService)
        {
            _policyHolderRepository = policyHolderRepository ?? throw new ArgumentNullException(nameof(policyHolderRepository));
            _policyService = policyService ?? throw new ArgumentNullException(nameof(policyService));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _encryptionService = encryptionService ?? throw new ArgumentNullException(nameof(encryptionService));
        }

        public async Task<IEnumerable<PolicyHolder>> GetAllPolicyHoldersAsync()
        {
            var policyHolders = await _policyHolderRepository.GetAllAsync();
            return policyHolders.Select(ph => 
            {
                ph.IDNumber = _encryptionService.Decrypt(ph.IDNumber);
                return ph;
            });
        }

        public async Task<PolicyHolder> GetPolicyHolderByIdAsync(int id)
        {
            var policyHolder = await _policyHolderRepository.GetByIdAsync(id);
            if (policyHolder != null)
            {
                policyHolder.IDNumber = _encryptionService.Decrypt(policyHolder.IDNumber);
            }
            return policyHolder;
        }

        public async Task<IEnumerable<Policy>> GetPoliciesByHolderIdAsync(int holderId)
        {
            if (holderId <= 0)
                throw new ArgumentException("Holder ID must be greater than zero.", nameof(holderId));
                
            return await _policyService.GetPoliciesByHolderIdAsync(holderId);
        }

        public async Task<PolicyHolder> GetPolicyHolderByIdNumberAsync(string idNumber)
        {
            var encryptedIdNumber = _encryptionService.Encrypt(idNumber);
            var policyHolder = await _policyHolderRepository.GetByIDNumberAsync(encryptedIdNumber);
            if (policyHolder != null)
            {
                policyHolder.IDNumber = idNumber; // Already decrypted by the repository
            }
            return policyHolder;
        }

        public async Task<IEnumerable<PolicyHolder>> SearchPolicyHoldersAsync(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
                return await GetAllPolicyHoldersAsync();

            // Search in decrypted ID numbers and names
            var allPolicyHolders = await _policyHolderRepository.GetAllAsync();
            var results = new List<PolicyHolder>();

            foreach (var ph in allPolicyHolders)
            {
                var decryptedIdNumber = _encryptionService.Decrypt(ph.IDNumber);
                if (decryptedIdNumber.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                    ph.Surname.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                    ph.Initials.Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
                {
                    ph.IDNumber = decryptedIdNumber;
                    results.Add(ph);
                }
            }

            return results;
        }

        public async Task<PolicyHolder> CreatePolicyHolderAsync(PolicyHolder policyHolder)
        {
            if (policyHolder == null)
                throw new ArgumentNullException(nameof(policyHolder));

            // Encrypt sensitive data before saving
            policyHolder.IDNumber = _encryptionService.Encrypt(policyHolder.IDNumber.Trim());

            await _policyHolderRepository.AddAsync(policyHolder);
            await _policyHolderRepository.SaveChangesAsync();

            // Decrypt for the returned object
            policyHolder.IDNumber = _encryptionService.Decrypt(policyHolder.IDNumber);
            return policyHolder;
        }

        public async Task<bool> UpdatePolicyHolderAsync(int id, PolicyHolder policyHolder)
        {
            if (policyHolder == null)
                throw new ArgumentNullException(nameof(policyHolder));

            var existingPolicyHolder = await _policyHolderRepository.GetByIdAsync(id);
            if (existingPolicyHolder == null)
                return false;

            // Encrypt the ID number if it was changed
            if (existingPolicyHolder.IDNumber != policyHolder.IDNumber)
            {
                policyHolder.IDNumber = _encryptionService.Encrypt(policyHolder.IDNumber.Trim());
            }

            // Update properties
            _mapper.Map(policyHolder, existingPolicyHolder);
            
            _policyHolderRepository.Update(existingPolicyHolder);
            return await _policyHolderRepository.SaveChangesAsync();
        }

        public async Task<bool> DeletePolicyHolderAsync(int id)
        {
            var policyHolder = await _policyHolderRepository.GetByIdAsync(id);
            if (policyHolder == null)
                return false;

            _policyHolderRepository.Remove(policyHolder);
            return await _policyHolderRepository.SaveChangesAsync();
        }

        public async Task<bool> PolicyHolderHasPoliciesAsync(int policyHolderId)
        {
            var policyHolder = await _policyHolderRepository.GetByIdAsync(policyHolderId);
            if (policyHolder == null)
                return false;

            // Check if the policy holder has any policies
            var policies = await _policyHolderRepository.GetPoliciesByHolderIdAsync(policyHolderId);
            return policies?.Any() == true;
        }
    }
}
