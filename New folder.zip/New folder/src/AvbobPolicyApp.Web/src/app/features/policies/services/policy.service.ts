import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { BaseApiService } from '../../../core/services/base-api.service';
import { API_CONFIG } from '../../../core/config/api.config';
import { Policy } from '../models/policy.model';
import { PolicyDocument } from '../models/policy-document.model';

@Injectable({
  providedIn: 'root'
})
export class PolicyService extends BaseApiService {
  constructor(
    protected override http: HttpClient,
    protected override router: Router
  ) {
    super(http, router, API_CONFIG.endpoints.policies.base);
  }

  /**
   * Get all policies with pagination and optional filtering
   * @param page The page number
   * @param pageSize The number of items per page
   * @param holderId Optional policy holder ID to filter by
   * @param searchTerm Optional search term
   */
  getPolicies(
    page: number = 1,
    pageSize: number = API_CONFIG.pagination.defaultPageSize,
    holderId?: number,
    searchTerm?: string
  ): Observable<{ items: Policy[]; pagination: any }> {
    const params: any = { pageNumber: page, pageSize };
    
    if (holderId) {
      params.holderId = holderId;
    }
    
    if (searchTerm) {
      params.searchTerm = searchTerm;
    }

    return this.get<Policy[]>('', params).pipe(
      map(response => ({
        items: response.body || [],
        pagination: this.getPaginationInfo(response) || {
          currentPage: page,
          pageSize,
          totalCount: 0,
          totalPages: 0,
          holderId,
          searchTerm
        }
      }))
    );
  }

  /**
   * Get a policy by ID
   * @param id The policy ID
   */
  getPolicyById(id: number): Observable<Policy> {
    return this.get<Policy>(`/${id}`).pipe(
      map(response => response.body as Policy)
    );
  }

  /**
   * Create a new policy
   * @param policy The policy data
   */
  createPolicy(policy: Partial<Policy>): Observable<Policy> {
    return this.post<Policy>('', policy).pipe(
      map(response => response.body as Policy)
    );
  }

  /**
   * Update an existing policy
   * @param id The policy ID
   * @param policy The updated policy data
   */
  updatePolicy(id: number, policy: Partial<Policy>): Observable<void> {
    return this.put<void>(`/${id}`, policy).pipe(
      map(() => {})
    );
  }

  /**
   * Delete a policy
   * @param id The policy ID
   */
  deletePolicy(id: number): Observable<void> {
    return this.delete<void>(`/${id}`).pipe(
      map(() => {})
    );
  }

  /**
   * Upload a document for a policy
   * @param policyId The policy ID
   * @param file The file to upload
   * @param documentType The type of document
   * @param description Optional document description
   */
  uploadDocument(
    policyId: number,
    file: File,
    documentType: string,
    description?: string
  ): Observable<PolicyDocument> {
    const formData: any = {
      documentType,
      uploadDate: new Date().toISOString()
    };
    
    if (description) {
      formData.description = description;
    }

    return this.upload<PolicyDocument>(
      `/${policyId}/documents`,
      file,
      formData
    ).pipe(
      map(response => response.body as PolicyDocument)
    );
  }

  /**
   * Get all documents for a policy
   * @param policyId The policy ID
   */
  getPolicyDocuments(policyId: number): Observable<PolicyDocument[]> {
    return this.get<PolicyDocument[]>(`/${policyId}/documents`).pipe(
      map(response => response.body || [])
    );
  }

  /**
   * Get a specific document
   * @param policyId The policy ID
   * @param documentId The document ID
   */
  getDocument(policyId: number, documentId: string): Observable<PolicyDocument> {
    return this.get<PolicyDocument>(`/${policyId}/documents/${documentId}`).pipe(
      map(response => response.body as PolicyDocument)
    );
  }

  /**
   * Delete a document
   * @param policyId The policy ID
   * @param documentId The document ID
   */
  deleteDocument(policyId: number, documentId: string): Observable<void> {
    return this.delete<void>(`/${policyId}/documents/${documentId}`).pipe(
      map(() => {})
    );
  }

  /**
   * Download a document
   * @param policyId The policy ID
   * @param documentId The document ID
   */
  downloadDocument(policyId: number, documentId: string): Observable<Blob> {
    return this.http.get(
      this.buildUrl(`/${policyId}/documents/${documentId}/download`),
      { responseType: 'blob' }
    );
  }

  /**
   * Get policy statistics
   */
  getStatistics(): Observable<{
    totalPolicies: number;
    activePolicies: number;
    expiredPolicies: number;
    totalPolicyHolders: number;
    recentPolicies: Policy[];
  }> {
    return this.get<{
      totalPolicies: number;
      activePolicies: number;
      expiredPolicies: number;
      totalPolicyHolders: number;
      recentPolicies: Policy[];
    }>('/statistics').pipe(
      map(response => response.body || {
        totalPolicies: 0,
        activePolicies: 0,
        expiredPolicies: 0,
        totalPolicyHolders: 0,
        recentPolicies: []
      })
    );
  }
}
