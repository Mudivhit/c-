using AvbobPolicyApp.Core.Entities;

namespace AvbobPolicyApp.Core.Interfaces
{
    public interface IPolicyHolderRepository : IRepository<PolicyHolder>
    {
        Task<PolicyHolder?> GetByIDNumberAsync(string idNumber);
        Task<IEnumerable<Policy>> GetPoliciesByHolderIdAsync(int holderId);
        Task<IEnumerable<PolicyHolder>> SearchAsync(string searchTerm);
    }
}
