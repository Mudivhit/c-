import { PolicyHolder } from './policy-holder.model';

export interface Policy {
  id?: number;
  policyNumber: string;
  policyType: string;
  commencementDate: string | Date;
  installment: number;
  applicationFormUrl?: string;
  policyHolderId?: number;
  policyHolder?: PolicyHolder;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface PolicyType {
  id: string;
  name: string;
  description?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  errors?: { [key: string]: string[] };
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}
