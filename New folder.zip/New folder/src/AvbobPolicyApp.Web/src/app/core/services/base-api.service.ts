import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { API_CONFIG, PaginationInfo } from '../../config/api.config';

@Injectable({
  providedIn: 'root'
})
export class BaseApiService {
  protected readonly apiUrl: string;
  protected readonly requestOptions: {
    headers: HttpHeaders;
    observe: 'response';
  };

  constructor(
    protected http: HttpClient,
    protected router: Router,
    protected endpoint: string = ''
  ) {
    // Use API config URL
    this.apiUrl = API_CONFIG.baseUrl;
    
    // Set up default request options
    this.requestOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }),
      observe: 'response' as const
    };
  }

  /**
   * Performs a GET request
   * @param path The API endpoint path
   * @param params Query parameters
   * @param options Additional request options
   */
  protected get<T>(
    path: string = '',
    params: any = {},
    options: any = {}
  ): Observable<HttpResponse<T>> {
    const url = this.buildUrl(path);
    const requestOptions = this.getRequestOptions({
      ...options,
      params: this.createParams(params)
    });

    return this.http
      .get<T>(url, requestOptions)
      .pipe(
        this.handleRetry(),
        catchError(this.handleError.bind(this))
      ) as Observable<HttpResponse<T>>;
  }

  /**
   * Performs a POST request
   * @param path The API endpoint path
   * @param body The request body
   * @param options Additional request options
   */
  protected post<T>(
    path: string = '',
    body: any = {},
    options: any = {}
  ): Observable<HttpResponse<T>> {
    const url = this.buildUrl(path);
    const requestOptions = this.getRequestOptions(options);

    return this.http
      .post<T>(url, body, requestOptions)
      .pipe(
        catchError(this.handleError.bind(this))
      ) as Observable<HttpResponse<T>>;
  }

  /**
   * Performs a PUT request
   * @param path The API endpoint path
   * @param body The request body
   * @param options Additional request options
   */
  protected put<T>(
    path: string = '',
    body: any = {},
    options: any = {}
  ): Observable<HttpResponse<T>> {
    const url = this.buildUrl(path);
    const requestOptions = this.getRequestOptions(options);

    return this.http
      .put<T>(url, body, requestOptions)
      .pipe(
        catchError(this.handleError.bind(this))
      ) as Observable<HttpResponse<T>>;
  }

  /**
   * Performs a PATCH request
   * @param path The API endpoint path
   * @param body The request body
   * @param options Additional request options
   */
  protected patch<T>(
    path: string = '',
    body: any = {},
    options: any = {}
  ): Observable<HttpResponse<T>> {
    const url = this.buildUrl(path);
    const requestOptions = this.getRequestOptions(options);

    return this.http
      .patch<T>(url, body, requestOptions)
      .pipe(
        catchError(this.handleError.bind(this))
      ) as Observable<HttpResponse<T>>;
  }

  /**
   * Performs a DELETE request
   * @param path The API endpoint path
   * @param options Additional request options
   */
  protected delete<T>(
    path: string = '',
    options: any = {}
  ): Observable<HttpResponse<T>> {
    const url = this.buildUrl(path);
    const requestOptions = this.getRequestOptions(options);

    return this.http
      .delete<T>(url, requestOptions)
      .pipe(
        catchError(this.handleError.bind(this))
      ) as Observable<HttpResponse<T>>;
  }

  /**
   * Uploads a file
   * @param path The API endpoint path
   * @param file The file to upload
   * @param formData Additional form data
   */
  protected upload<T>(
    path: string,
    file: File,
    formData: { [key: string]: any } = {}
  ): Observable<HttpResponse<T>> {
    const url = this.buildUrl(path);
    const form = new FormData();
    
    // Add the file
    form.append('file', file, file.name);
    
    // Add additional form data
    Object.entries(formData).forEach(([key, value]) => {
      if (value !== null && value !== undefined) {
        form.append(key, value);
      }
    });

    const requestOptions = {
      ...this.requestOptions,
      headers: new HttpHeaders({
        // Remove Content-Type to let the browser set it with the correct boundary
      }),
      reportProgress: true
    };

    return this.http.post<T>(url, form, requestOptions).pipe(
      catchError(this.handleError.bind(this))
    ) as Observable<HttpResponse<T>>;
  }

  /**
   * Builds the full URL for an API request
   * @param path The API endpoint path
   */
  protected buildUrl(path: string = ''): string {
    // Remove leading/trailing slashes
    const endpoint = this.endpoint.replace(/^\/+|\/+$/g, '');
    const apiPath = path.replace(/^\/+|\/+$/g, '');
    
    // Build the URL parts
    const parts = [this.apiUrl, endpoint, apiPath].filter(Boolean);
    return parts.join('/');
  }

  /**
   * Creates HTTP params from an object
   * @param params The parameters object
   */
  protected createParams(params: { [key: string]: any }): HttpParams {
    let httpParams = new HttpParams();
    
    if (!params) {
      return httpParams;
    }

    Object.entries(params).forEach(([key, value]) => {
      if (value !== null && value !== undefined) {
        if (Array.isArray(value)) {
          value.forEach(item => {
            if (item !== null && item !== undefined) {
              httpParams = httpParams.append(key, item.toString());
            }
          });
        } else if (value instanceof Date) {
          httpParams = httpParams.set(key, value.toISOString());
        } else if (value !== '') {
          httpParams = httpParams.set(key, value.toString());
        }
      }
    });

    return httpParams;
  }

  /**
   * Gets the request options with defaults
   * @param options Custom request options
   */
  protected getRequestOptions(options: any = {}): any {
    return {
      ...this.requestOptions,
      ...options,
      headers: this.mergeHeaders(this.requestOptions.headers, options.headers)
    };
  }

  /**
   * Merges multiple header objects
   * @param headers1 First headers object
   * @param headers2 Second headers object
   */
  protected mergeHeaders(
    headers1: HttpHeaders,
    headers2?: HttpHeaders | { [header: string]: string | string[] }
  ): HttpHeaders {
    if (!headers2) {
      return headers1;
    }

    let result = new HttpHeaders();

    // Add headers from the first set
    headers1.keys().forEach(key => {
      const values = headers1.getAll(key);
      if (values) {
        values.forEach(value => {
          result = result.append(key, value);
        });
      }
    });

    // Add or override with headers from the second set
    if (headers2 instanceof HttpHeaders) {
      headers2.keys().forEach(key => {
        const values = headers2.getAll(key);
        if (values) {
          result = result.set(key, values);
        }
      });
    } else if (typeof headers2 === 'object') {
      Object.entries(headers2).forEach(([key, value]) => {
        if (Array.isArray(value)) {
          result = result.set(key, value.join(','));
        } else {
          result = result.set(key, value);
        }
      });
    }

    return result;
  }

  /**
   * Handles retry logic for failed requests - simplified for local development
   */
  protected handleRetry() {
    return (source: Observable<any>) => source;
  }

  /**
   * Handles HTTP errors - simplified for local development
   * @param error The error response
   */
  protected handleError(error: HttpErrorResponse) {
    let errorMessage = 'An error occurred';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side or network error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      errorMessage = error.error?.message || error.message || error.statusText;
      
      // Simplified error handling for local development
      if (error.status === 404) {
        errorMessage = 'Resource not found';
      } else if (error.status === 400) {
        errorMessage = 'Bad request';
        if (error.error?.errors) {
          console.error('Validation errors:', error.error.errors);
        }
      } else if (error.status >= 500) {
        errorMessage = 'Server error';
      }
    }
    
    console.error(`API Error [${error.status}]:`, errorMessage, error.error);
    
    // Return a user-friendly error
    return throwError(() => ({
      message: errorMessage,
      details: error.error,
      status: error.status
    }));
  }

  /**
   * Extracts pagination info from response headers
   * @param response The HTTP response
   */
  protected getPaginationInfo(response: HttpResponse<any>): PaginationInfo | null {
    const paginationHeader = response.headers.get('X-Pagination');
    if (!paginationHeader) return null;
    
    try {
      return JSON.parse(paginationHeader);
    } catch (error) {
      console.error('Error parsing pagination header:', error);
      return null;
    }
  }
}
