import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { BaseApiService } from '../../../core/services/base-api.service';
import { API_CONFIG } from '../../../core/config/api.config';
import { PolicyHolder } from '../models/policy-holder.model';
import { Policy } from '../../policies/models/policy.model';

@Injectable({
  providedIn: 'root'
})
export class PolicyHolderService extends BaseApiService {
  constructor(
    protected http: HttpClient,
    protected router: Router
  ) {
    super(http, router, API_CONFIG.endpoints.policyHolders.base);
  }

  /**
   * Get all policy holders with pagination and search
   * @param page The page number
   * @param pageSize The number of items per page
   * @param searchTerm Optional search term
   */
  getPolicyHolders(
    page: number = 1,
    pageSize: number = API_CONFIG.pagination.defaultPageSize,
    searchTerm?: string
  ): Observable<{ items: PolicyHolder[]; pagination: any }> {
    const params: any = { pageNumber: page, pageSize };
    
    if (searchTerm) {
      params.searchTerm = searchTerm;
    }

    return this.get<PolicyHolder[]>('', params).pipe(
      map(response => ({
        items: response.body || [],
        pagination: this.getPaginationInfo(response) || {
          currentPage: page,
          pageSize,
          totalCount: 0,
          totalPages: 0
        }
      }))
    );
  }

  /**
   * Get a policy holder by ID
   * @param id The policy holder ID
   */
  getPolicyHolderById(id: number): Observable<PolicyHolder> {
    return this.get<PolicyHolder>(`/${id}`).pipe(
      map(response => response.body as PolicyHolder)
    );
  }

  /**
   * Get a policy holder by ID number
   * @param idNumber The policy holder's ID number
   */
  getPolicyHolderByIdNumber(idNumber: string): Observable<PolicyHolder> {
    return this.get<PolicyHolder>(`/search/id-number/${idNumber}`).pipe(
      map(response => response.body as PolicyHolder)
    );
  }

  /**
   * Search for policy holders by search term
   * @param searchTerm The search term
   * @param page The page number
   * @param pageSize The number of items per page
   */
  searchPolicyHolders(
    searchTerm: string,
    page: number = 1,
    pageSize: number = API_CONFIG.pagination.defaultPageSize
  ): Observable<{ items: PolicyHolder[]; pagination: any }> {
    return this.get<PolicyHolder[]>('', { 
      searchTerm, 
      pageNumber: page, 
      pageSize 
    }).pipe(
      map(response => ({
        items: response.body || [],
        pagination: this.getPaginationInfo(response) || {
          currentPage: page,
          pageSize,
          totalCount: 0,
          totalPages: 0,
          searchTerm
        }
      }))
    );
  }

  /**
   * Create a new policy holder
   * @param policyHolder The policy holder data
   */
  createPolicyHolder(policyHolder: Partial<PolicyHolder>): Observable<PolicyHolder> {
    return this.post<PolicyHolder>('', policyHolder).pipe(
      map(response => response.body as PolicyHolder)
    );
  }

  /**
   * Update an existing policy holder
   * @param id The policy holder ID
   * @param policyHolder The updated policy holder data
   */
  updatePolicyHolder(id: number, policyHolder: Partial<PolicyHolder>): Observable<void> {
    return this.put<void>(`/${id}`, policyHolder).pipe(
      map(() => {})
    );
  }

  /**
   * Delete a policy holder
   * @param id The policy holder ID
   */
  deletePolicyHolder(id: number): Observable<void> {
    return this.delete<void>(`/${id}`).pipe(
      map(() => {})
    );
  }

  /**
   * Get policies for a specific policy holder
   * @param holderId The policy holder ID
   * @param page The page number
   * @param pageSize The number of items per page
   */
  getPoliciesByHolderId(
    holderId: number,
    page: number = 1,
    pageSize: number = API_CONFIG.pagination.defaultPageSize
  ): Observable<{ items: Policy[]; pagination: any }> {
    return this.get<Policy[]>(`/${holderId}/policies`, { pageNumber: page, pageSize }).pipe(
      map(response => ({
        items: response.body || [],
        pagination: this.getPaginationInfo(response) || {
          currentPage: page,
          pageSize,
          totalCount: 0,
          totalPages: 0,
          policyHolderId: holderId
        }
      }))
    );
  }

  /**
   * Check if a policy holder has any policies
   * @param holderId The policy holder ID
   */
  hasPolicies(holderId: number): Observable<boolean> {
    return this.getPoliciesByHolderId(holderId, 1, 1).pipe(
      map(result => result.items.length > 0)
    );
  }
}
