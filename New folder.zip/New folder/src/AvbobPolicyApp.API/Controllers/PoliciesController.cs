using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using AvbobPolicyApp.Core.Entities;
using AvbobPolicyApp.Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace AvbobPolicyApp.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PoliciesController : BaseApiController
    {
        private readonly IPolicyService _policyService;
        private readonly ILogger<PoliciesController> _logger;

        public PoliciesController(
            IPolicyService policyService,
            ILogger<PoliciesController> logger) : base(logger)
        {
            _policyService = policyService ?? throw new ArgumentNullException(nameof(policyService));
            _logger = logger;
        }

        // GET: api/policies
        /// <summary>
        /// Gets all policies, optionally filtered by holder ID
        /// </summary>
        /// <param name="holderId">Optional holder ID to filter policies</param>
        /// <param name="pageNumber">Page number for pagination</param>
        /// <param name="pageSize">Number of items per page</param>
        /// <returns>List of policies</returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetPolicies(
            [FromQuery] int? holderId = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 20)
        {
            if (pageNumber < 1) pageNumber = 1;
            if (pageSize < 1 || pageSize > 100) pageSize = 20;

            try
            {
                IEnumerable<Policy> policies;
                if (holderId.HasValue && holderId > 0)
                {
                    policies = await _policyService.GetPoliciesByHolderIdAsync(holderId.Value);
                }
                else
                {
                    policies = await _policyService.GetPoliciesByHolderIdAsync(0); // 0 means get all
                }

                // Apply pagination
                var paginatedPolicies = policies
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToList();

                // Add pagination headers
                Response.Headers.Add("X-Pagination", 
                    System.Text.Json.JsonSerializer.Serialize(new 
                    { 
                        TotalCount = policies.Count(),
                        PageSize = pageSize,
                        CurrentPage = pageNumber,
                        TotalPages = (int)Math.Ceiling(policies.Count() / (double)pageSize)
                    }));

                return Ok(paginatedPolicies);
            }
            catch (Exception ex)
            {
                return HandleException(ex, "An error occurred while retrieving policies");
            }
        }

        // GET: api/policies/5
        /// <summary>
        /// Gets a policy by ID
        /// </summary>
        /// <param name="id">The ID of the policy to retrieve</param>
        /// <returns>The requested policy</returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetPolicy(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid policy ID");
            }

            try
            {
                var policy = await _policyService.GetPolicyByIdAsync(id);
                return HandleResult(policy, $"Policy with ID {id} not found");
            }
            catch (Exception ex)
            {
                return HandleException(ex, $"Error retrieving policy with ID {id}");
            }
        }

        // GET: api/policies/number/POL123456
        [HttpGet("number/{policyNumber}")]
        public async Task<IActionResult> GetByPolicyNumber(string policyNumber)
        {
            try
            {
                // First check if the method exists in the service
                var policy = await _policyService.GetPolicyByNumberAsync(policyNumber);
                return HandleResult(policy, $"Policy with number {policyNumber} not found");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving policy with number {policyNumber}");
                return HandleException(ex, $"An error occurred while retrieving policy with number {policyNumber}");
            }
        }

        // GET: api/policies/holder/5
        [HttpGet("holder/{holderId}")]
        public async Task<IActionResult> GetByHolderId(int holderId)
        {
            try
            {
                // First check if the method exists in the service
                var policies = await _policyService.GetPoliciesByHolderIdAsync(holderId);
                return HandleResult(policies, $"No policies found for holder ID {holderId}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving policies for holder ID {holderId}");
                return HandleException(ex, $"An error occurred while retrieving policies for holder ID {holderId}");
            }
        }

        // POST: api/policies
        /// <summary>
        /// Creates a new policy
        /// </summary>
        /// <param name="policy">The policy to create</param>
        /// <returns>The created policy</returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreatePolicy([FromBody] Policy policy)
        {
            var validationResult = ValidateModelState();
            if (validationResult != null)
            {
                return validationResult;
            }

            try
            {
                var createdPolicy = await _policyService.CreatePolicyAsync(policy);
                return HandleCreatedResult(createdPolicy, nameof(GetPolicy), new { id = createdPolicy?.Id }, "Failed to create policy");
            }
            catch (Exception ex)
            {
                return HandleException(ex, "Error creating policy");
            }
        }

        // PUT: api/policies/5
        /// <summary>
        /// Updates an existing policy
        /// </summary>
        /// <param name="id">The ID of the policy to update</param>
        /// <param name="policy">The updated policy data</param>
        /// <returns>No content if successful</returns>
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UpdatePolicy(int id, [FromBody] Policy policy)
        {
            if (id != policy?.Id)
            {
                return BadRequest("ID in route does not match ID in request body");
            }

            var validationResult = ValidateModelState();
            if (validationResult != null)
            {
                return validationResult;
            }

            try
            {
                var result = await _policyService.UpdatePolicyAsync(id, policy);
                if (!result)
                {
                    return NotFound($"Policy with ID {id} not found");
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                return HandleException(ex, $"Error updating policy with ID {id}");
            }
        }

        // DELETE: api/policies/5
        /// <summary>
        /// Deletes a policy
        /// </summary>
        /// <param name="id">The ID of the policy to delete</param>
        /// <returns>No content if successful</returns>
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> DeletePolicy(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid policy ID");
            }

            try
            {
                var result = await _policyService.DeletePolicyAsync(id);
                if (!result)
                {
                    return NotFound($"Policy with ID {id} not found");
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                return HandleException(ex, $"Error deleting policy with ID {id}");
            }
        }

        // POST: api/policies/5/documents
        /// <summary>
        /// Uploads a document for a policy
        /// </summary>
        /// <param name="id">The ID of the policy</param>
        /// <param name="file">The file to upload</param>
        /// <returns>The path to the uploaded file</returns>
        [HttpPost("{id}/documents")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UploadDocument(int id, IFormFile file)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid policy ID");
            }

            if (file == null || file.Length == 0)
            {
                return BadRequest("No file provided or file is empty");
            }

            // Validate file size (e.g., 10MB max)
            var maxFileSize = 10 * 1024 * 1024; // 10MB
            if (file.Length > maxFileSize)
            {
                return BadRequest("File size exceeds the maximum allowed size of 10MB");
            }

            // Validate file extension
            var allowedExtensions = new[] { ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".jpg", ".jpeg", ".png" };
            var fileExtension = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (string.IsNullOrEmpty(fileExtension) || !allowedExtensions.Contains(fileExtension))
            {
                return BadRequest($"File type not allowed. Allowed types: {string.Join(", ", allowedExtensions)}");
            }

            try
            {
                using var stream = file.OpenReadStream();
                var filePath = await _policyService.UploadPolicyDocumentAsync(id, file.FileName, stream);
                
                return Ok(new { filePath });
            }
            catch (KeyNotFoundException ex)
            {
                _logger.LogError(ex, $"Policy with ID {id} not found");
                return NotFound($"Policy with ID {id} not found");
            }
            catch (Exception ex)
            {
                return HandleException(ex, $"Error uploading document for policy with ID {id}");
            }
        }
    }
}
