using System.Net;
using System.Text.Json;
using AvbobPolicyApp.Shared.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace AvbobPolicyApp.API.Filters
{
    public class GlobalExceptionFilter : IExceptionFilter
    {
        private readonly ILogger<GlobalExceptionFilter> _logger;
        private readonly IWebHostEnvironment _env;

        public GlobalExceptionFilter(ILogger<GlobalExceptionFilter> logger, IWebHostEnvironment env)
        {
            _logger = logger;
            _env = env;
        }

        public void OnException(ExceptionContext context)
        {
            _logger.LogError(new EventId(context.Exception.HResult),
                context.Exception,
                context.Exception.Message);

            var isDevelopment = _env.IsDevelopment();
            var error = new ApiErrorResponse
            {
                StatusCode = (int)HttpStatusCode.InternalServerError,
                Message = "An unexpected error occurred. Please try again later.",
                Details = isDevelopment ? context.Exception.ToString() : null,
                StackTrace = isDevelopment ? context.Exception.StackTrace : null
            };

            // Handle specific exceptions
            switch (context.Exception)
            {
                case UnauthorizedAccessException _:
                    error.StatusCode = (int)HttpStatusCode.Unauthorized;
                    error.Message = "You are not authorized to perform this action.";
                    break;
                case InvalidOperationException _:
                case ArgumentException _:
                    error.StatusCode = (int)HttpStatusCode.BadRequest;
                    error.Message = context.Exception.Message;
                    break;
                case KeyNotFoundException _:
                    error.StatusCode = (int)HttpStatusCode.NotFound;
                    error.Message = "The requested resource was not found.";
                    break;
                case NotImplementedException _:
                    error.StatusCode = (int)HttpStatusCode.NotImplemented;
                    error.Message = "This feature is not yet implemented.";
                    break;
            }

            context.Result = new ObjectResult(error)
            {
                StatusCode = error.StatusCode,
                ContentTypes = { "application/json" }
            };

            context.ExceptionHandled = true;
        }
    }

    public class ApiErrorResponse
    {
        public int StatusCode { get; set; }
        public string Message { get; set; } = string.Empty;
        public string? Details { get; set; }
        public string? StackTrace { get; set; }

        public override string ToString()
        {
            return JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
        }
    }
}
