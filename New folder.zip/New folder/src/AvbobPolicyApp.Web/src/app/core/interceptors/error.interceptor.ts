import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        let errorMessage = 'An error occurred';
        
        // Client-side or network error
        if (error.error instanceof ErrorEvent) {
          errorMessage = `Error: ${error.error.message}`;
        } else {
          // Server-side error
          errorMessage = error.error?.message || error.message || error.statusText;
          
          // Simplified error handling for local development
          if (error.status === 404) {
            errorMessage = 'Resource not found';
          } else if (error.status === 400) {
            errorMessage = 'Bad request';
            if (error.error?.errors) {
              console.error('Validation errors:', error.error.errors);
            }
          } else if (error.status >= 500) {
            errorMessage = 'Server error';
          }
        }
        
        console.error(`API Error [${error.status}]:`, errorMessage, error.error);
        
        // Return a user-friendly error
        return throwError(() => ({
          message: errorMessage,
          details: error.error,
          status: error.status
        }));
      })
    );
  }
}
