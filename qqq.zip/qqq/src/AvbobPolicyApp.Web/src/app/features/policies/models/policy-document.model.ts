/**
 * Represents a document attached to a policy
 */
export interface PolicyDocument {
  /** Unique identifier for the document */
  id: string;
  
  /** ID of the policy this document belongs to */
  policyId: number;
  
  /** Original filename of the document */
  fileName: string;
  
  /** File extension */
  fileExtension: string;
  
  /** MIME type of the document */
  contentType: string;
  
  /** Size of the file in bytes */
  fileSize: number;
  
  /** Type/category of the document (e.g., PolicySchedule, ID, ProofOfPayment) */
  documentType: string;
  
  /** Optional description of the document */
  description?: string;
  
  /** Date when the document was uploaded */
  uploadDate: Date;
  
  /** User who uploaded the document */
  uploadedBy?: string;
  
  /** Version of the document, if applicable */
  version?: string;
  
  /** Whether the document is the latest version */
  isLatestVersion: boolean;
  
  /** URL to download the document (client-side only) */
  downloadUrl?: string;
  
  /** URL to preview the document (client-side only) */
  previewUrl?: string;
  
  /** Thumbnail URL for images/PDFs (client-side only) */
  thumbnailUrl?: string;
}

/**
 * Represents a request to upload a new document
 */
export interface UploadDocumentRequest {
  /** The file to upload */
  file: File;
  
  /** Type/category of the document */
  documentType: string;
  
  /** Optional description */
  description?: string;
  
  /** Optional version number */
  version?: string;
}

/**
 * Represents a request to update document metadata
 */
export interface UpdateDocumentRequest {
  /** New document type */
  documentType?: string;
  
  /** New description */
  description?: string;
  
  /** New version number */
  version?: string;
}

/**
 * Represents a document type definition
 */
export interface DocumentType {
  /** Unique identifier for the document type */
  id: string;
  
  /** Display name of the document type */
  name: string;
  
  /** Description of when this document type is used */
  description?: string;
  
  /** Whether this document type is required for policy activation */
  isRequired: boolean;
  
  /** Allowed file extensions for this document type */
  allowedExtensions: string[];
  
  /** Maximum file size in bytes */
  maxFileSize: number;
  
  /** Whether multiple documents of this type are allowed */
  allowMultiple: boolean;
}
