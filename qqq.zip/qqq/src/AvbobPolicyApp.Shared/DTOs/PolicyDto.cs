using System.ComponentModel.DataAnnotations;

namespace AvbobPolicyApp.Shared.DTOs
{
    public class PolicyDto
    {
        public int Id { get; set; }
        
        [Required(ErrorMessage = "Policy Number is required")]
        [StringLength(20, ErrorMessage = "Policy Number cannot exceed 20 characters")]
        public string PolicyNumber { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "Policy Type is required")]
        [StringLength(50, ErrorMessage = "Policy Type cannot exceed 50 characters")]
        public string PolicyType { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "Commencement Date is required")]
        [DataType(DataType.Date)]
        public DateTime CommencementDate { get; set; }
        
        [Required(ErrorMessage = "Installment amount is required")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Installment must be greater than 0")]
        public decimal Installment { get; set; }
        
        public string? ApplicationFormPath { get; set; }
        
        [Required(ErrorMessage = "Policy Holder is required")]
        public int PolicyHolderId { get; set; }
        
        // For display purposes
        public string? PolicyHolderName { get; set; }
    }
}
