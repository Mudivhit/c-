using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using AvbobPolicyApp.Core.Interfaces;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Configuration;

namespace AvbobPolicyApp.Infrastructure.Services
{
    public class EncryptionService : IEncryptionService, IDisposable
    {
        private readonly IDataProtector _protector;
        private readonly IConfiguration _configuration;
        private bool _disposed = false;

        public EncryptionService(
            IDataProtectionProvider dataProtectionProvider,
            IConfiguration configuration)
        {
            _protector = dataProtectionProvider.CreateProtector("AvbobPolicyApp.Protection");
            _configuration = configuration;
        }

        public string Encrypt(string plainText)
        {
            if (string.IsNullOrEmpty(plainText))
                return plainText;

            try
            {
                return _protector.Protect(plainText);
            }
            catch (CryptographicException)
            {
                // Log error or handle it as needed
                throw new InvalidOperationException("Failed to encrypt data.");
            }
        }

        public string Decrypt(string cipherText)
        {
            if (string.IsNullOrEmpty(cipherText))
                return cipherText;

            try
            {
                return _protector.Unprotect(cipherText);
            }
            catch (CryptographicException)
            {
                // Log error or handle it as needed
                throw new InvalidOperationException("Failed to decrypt data. The data may be corrupted or the protection key may have changed.");
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    // No managed resources to dispose
                }

                _disposed = true;
            }
        }
    }
}
