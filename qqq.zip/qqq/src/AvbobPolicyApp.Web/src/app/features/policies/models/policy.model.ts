/**
 * Represents a policy in the system
 */
export interface Policy {
  /** Unique identifier for the policy */
  id: number;
  
  /** Policy number */
  policyNumber: string;
  
  /** Policy type (e.g., Life, Funeral, Investment) */
  policyType: string;
  
  /** ID of the policy holder */
  policyHolderId: number;
  
  /** Policy holder details (may be included in some responses) */
  policyHolder?: {
    id: number;
    fullName: string;
    idNumber: string;
  };
  
  /** Policy status (Active, Lapsed, Surrendered, Matured, etc.) */
  status: 'Active' | 'Lapsed' | 'Surrendered' | 'Matured' | 'Deceased' | 'Other';
  
  /** Premium amount */
  premiumAmount: number;
  
  /** Premium frequency (Monthly, Quarterly, Bi-Annually, Annually) */
  premiumFrequency: 'Monthly' | 'Quarterly' | 'BiAnnually' | 'Annually' | 'Single';
  
  /** Sum assured/cover amount */
  sumAssured: number;
  
  /** Policy start date */
  startDate: Date;
  
  /** Policy maturity/end date */
  endDate?: Date;
  
  /** Last premium paid date */
  lastPremiumDate?: Date;
  
  /** Next premium due date */
  nextPremiumDate?: Date;
  
  /** Payment method (Debit Order, Stop Order, EFT, etc.) */
  paymentMethod: string;
  
  /** Bank account details for premium collection */
  bankAccount?: {
    accountHolder: string;
    accountNumber: string;
    branchCode: string;
    bankName: string;
    accountType: 'Savings' | 'Cheque' | 'Transmission' | 'Other';
  };
  
  /** Beneficiaries of the policy */
  beneficiaries?: Array<{
    name: string;
    idNumber: string;
    relationship: string;
    percentage: number;
  }>;
  
  /** Any additional notes */
  notes?: string;
  
  /** Date when the policy was created */
  createdOn: Date;
  
  /** Last modified date */
  modifiedOn?: Date;
  
  /** Number of documents attached to this policy */
  documentCount?: number;
}

/**
 * Represents a summary of a policy for listing
 */
export interface PolicySummary {
  id: number;
  policyNumber: string;
  policyType: string;
  policyHolderId: number;
  policyHolderName: string;
  status: string;
  premiumAmount: number;
  sumAssured: number;
  nextPremiumDate?: Date;
  documentCount: number;
}

/**
 * Request payload for creating or updating a policy
 */
export interface PolicyRequest {
  policyNumber: string;
  policyType: string;
  policyHolderId: number;
  status: string;
  premiumAmount: number;
  premiumFrequency: string;
  sumAssured: number;
  startDate: string | Date;
  endDate?: string | Date;
  lastPremiumDate?: string | Date;
  nextPremiumDate?: string | Date;
  paymentMethod: string;
  bankAccount?: {
    accountHolder: string;
    accountNumber: string;
    branchCode: string;
    bankName: string;
    accountType: string;
  };
  beneficiaries?: Array<{
    name: string;
    idNumber: string;
    relationship: string;
    percentage: number;
  }>;
  notes?: string;
}

/**
 * Response from searching policies
 */
export interface PolicySearchResponse {
  items: PolicySummary[];
  pagination: {
    currentPage: number;
    pageSize: number;
    totalCount: number;
    totalPages: number;
    holderId?: number;
    searchTerm?: string;
  };
}

/**
 * Represents policy statistics
 */
export interface PolicyStatistics {
  totalPolicies: number;
  activePolicies: number;
  expiredPolicies: number;
  totalPolicyHolders: number;
  totalPremiumAmount: number;
  totalSumAssured: number;
  recentPolicies: PolicySummary[];
  policiesByType: Array<{
    policyType: string;
    count: number;
    percentage: number;
  }>;
  policiesByStatus: Array<{
    status: string;
    count: number;
    percentage: number;
  }>;
}
